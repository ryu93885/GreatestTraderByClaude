//+------------------------------------------------------------------+
//|                                              GreatestTrader.mq5  |
//|   Multi-strategy FX portfolio EA (MT5 Strategy Tester edition)   |
//|                                                                  |
//|   Strategy 1  Night Reversion (NR)  - core                       |
//|   Strategy 2  Euro Session   (ES)  - satellite                   |
//|   Logic is identical to the Python production engine.            |
//|                                                                  |
//|   v1.2 long-term operation:                                      |
//|   - lot caps (InpMaxLotsPerOrder / InpMaxRiskAmount / broker)    |
//|   - deposits / withdrawals / credit are not profit or loss       |
//|   - broker clock verified from live ticks (GT_SERVER_AUTO)       |
//|   - start-up and state safety, instance lock, hedging only       |
//|   - order retries, close back-off, monitoring alerts             |
//+------------------------------------------------------------------+
#property copyright   "GreatestTrader"
#property version     "1.20"
#property description "Night Reversion (14 crosses, 00:00-02:00 market time) + Euro Session (EURUSD 07-13 UTC). Defaults = STABLE5 preset."
#property description "Attach to ONE chart (any symbol, any timeframe) of a HEDGING account. The EA trades all configured symbols."

#include <Trade/Trade.mqh>

//--- enums
enum ENUM_GT_RISK
  {
   GT_RISK_CONSERVATIVE = 0, // Conservative 0.5% per trade
   GT_RISK_STANDARD     = 1, // Standard 1.0% per trade
   GT_RISK_AGGRESSIVE   = 2, // Aggressive 1.5% per trade (v1.0 classic; load Classic_Aggressive.set)
   GT_RISK_CUSTOM       = 3  // Custom (InpRiskNR / InpRiskES)
  };

enum ENUM_GT_SERVER_TIME
  {
   GT_SERVER_NY7   = 0, // GMT+2 winter / GMT+3 summer (US DST) - most brokers
   GT_SERVER_FIXED = 1, // Fixed GMT offset (InpServerGMTOffset)
   GT_SERVER_AUTO  = 2  // Auto: measured from live ticks (tester: NY7)
  };

//--- inputs
input group "=== Risk management ==="
input ENUM_GT_RISK InpRiskProfile      = GT_RISK_CUSTOM; // Risk profile (default = STABLE5 preset)
input double       InpRiskNR           = 3.5;   // Custom: NR risk per trade (% of equity)
input double       InpRiskES           = 1.75;  // Custom: ES risk per trade (% of equity)
input int          InpMaxOpen          = 10;    // Max open positions (total)
input int          InpMaxPerCurrency   = 4;     // Max positions per currency
input double       InpDDScaleFull      = 10.0;  // DD scaling: risk x max(floor, 1 - DD%/this)
input double       InpDDScaleFloor     = 0.10;  // DD scaling: minimum multiplier
input double       InpDailyLossLimit   = 1.0;   // Daily loss limit (% of day-start equity)
input double       InpMaxDDHalt        = 20.0;  // Halt new entries at this DD (%) from peak (InpResetHalt clears it)
input bool         InpUseMinLot        = false; // Use min lot when calculated lot is smaller
input double       InpMaxTotalRisk     = 8.75;  // Max total open risk (% of equity, 0 = off)
input double       InpMaxLotsPerOrder  = 20.0;  // Max lots per order, all strategies (0 = off; broker volume max still applies)
input double       InpMaxRiskAmount    = 0.0;   // Max risk per trade in account currency, entry to stop (0 = off)
input int          InpMaxSameDirPerCcy = 2;     // Max same-direction positions per currency (0 = off)
input double       InpDailyHardStop    = 0.0;   // Daily hard stop: close all at this loss (%, 0 = off)
input double       InpMonthlyLossLimit = 0.0;   // Monthly loss limit: no new entries (%, 0 = off)
input double       InpMonthlyHardStop  = 3.0;   // Monthly hard stop: close all at this loss (%, 0 = off)
input string       InpSymbolRiskMult   = "EURJPY:0.25,GBPJPY:0.25,USDJPY:0.25,GBPUSD:0.25,EURGBP:0.25,USDCHF:0.25,EURUSD:0.25,EURAUD:0.25,CHFJPY:0.25,GBPAUD:0.25"; // Per-symbol risk multipliers (SYM:mult,...)
input double       InpVolTargetDaily   = 0.0;   // Volatility target, daily equity vol (%, 0 = off)
input int          InpVolLookbackDays  = 20;    // Volatility target lookback (days)
input double       InpVolMultMin       = 0.25;  // Volatility target min multiplier
input double       InpVolMultMax       = 1.5;   // Volatility target max multiplier
input int          InpEqFilterDays     = 0;     // Equity-curve filter SMA (days, 0 = off)
input double       InpEqFilterMult     = 0.5;   // Equity-curve filter multiplier below SMA
input string       InpBlackoutStart    = "12-20"; // Year-end blackout start MM-DD (no new entries, empty = off)
input string       InpBlackoutEnd      = "01-05"; // Year-end blackout end MM-DD (inclusive)

input group "=== Broker ==="
input string              InpSymbolSuffix     = "";             // Symbol suffix (e.g. .raw  -STD  m)
input ENUM_GT_SERVER_TIME InpServerTime       = GT_SERVER_AUTO; // Broker server time (AUTO = measured from live ticks)
input double              InpServerGMTOffset  = 2.0;            // Fixed GMT offset (hours) if Fixed
input double              InpCommissionPerLot = 0.0;            // Round-trip commission per lot (account ccy)
input int                 InpDeviationPoints  = 20;             // Max slippage (points)

input group "=== Strategy 1: Night Reversion ==="
input bool   InpNREnabled       = true;  // Enable Night Reversion
input string InpNRSymbols       = "EURJPY,GBPJPY,USDJPY,GBPUSD,EURGBP,USDCHF,EURUSD,GBPCAD,EURCAD,AUDCAD,GBPCHF,EURAUD,CHFJPY,GBPAUD"; // Symbols (comma separated)
input int    InpBBPeriod        = 15;    // Bollinger period (M15)
input double InpBBDev           = 1.8;   // Bollinger deviation
input int    InpATRPeriod       = 14;    // ATR period (M15)
input double InpATRCostMult     = 2.0;   // Min ATR / trading cost ratio
input double InpSLATRMult       = 3.0;   // Stop loss = ATR x this
input int    InpMaxHoldBars     = 12;    // Time stop (M15 bars)
input int    InpEntryHour1      = 0;     // Entry hour 1 (market time = NY+7)
input int    InpEntryHour2      = 1;     // Entry hour 2 (-1 = off)
input bool   InpSkipMonday      = true;  // Skip Monday
input double InpNRSlippagePips  = 0.5;   // Slippage allowance in cost filter (pips)
input double InpNRMaxSpreadPips = 5.0;   // Max spread (pips)
input double InpMaxBandZ        = 0.0;   // News filter: skip if |close-mid| > this x stdev (0 = off)
input double InpMaxBarRangeATR  = 0.0;   // News filter: skip if bar range > this x ATR (0 = off)
input long   InpNRMagic         = 7101;  // Magic number NR

input group "=== Strategy 2: Euro Session ==="
input bool   InpESEnabled       = true;     // Enable Euro Session
input string InpESSymbol        = "EURUSD"; // Symbol
input int    InpESDirection     = -1;       // Direction (-1 sell, 1 buy)
input int    InpESEntryUTC      = 7;        // Entry hour (UTC)
input int    InpESExitUTC       = 13;       // Exit hour (UTC)
input int    InpESATRPeriodH1   = 24;       // ATR period (H1)
input double InpESSLATRMult     = 3.0;      // Stop loss = ATR(H1) x this
input double InpESMaxSpreadPips = 2.0;      // Max spread (pips)
input long   InpESMagic         = 7102;     // Magic number ES

input group "=== Misc ==="
input bool   InpPushNotify  = false; // Push notifications (MetaQuotes ID required)
input int    InpTimerSec    = 5;     // Timer (seconds, live). Tester uses 60s
input bool   InpVerbose     = false; // Verbose log
input double InpDDAlert     = 15.0;  // Alert when drawdown from peak >= this % (notification only, 0 = off)
input bool   InpResetHalt   = false; // Clear the max-DD halt once at start (peak := equity), then set back to false

//--- constants
#define GT_FRESH_SEC        150     // act on a closed M15 bar only within this many seconds of its close (Python FRESH_SIGNAL)
#define GT_BAR_SETTLE_SEC   2       // live: a bar counts as closed this long after its end (late ticks of the old bar)
#define GT_CLOCK_TOL_SEC    120     // a valid observation: server - UTC within this of a whole half-hour offset
#define GT_CLOCK_ADV_SEC    30      // clock observations only while the server time advanced within this many seconds
#define GT_CLOCK_OBS_SEC    60      // spacing of counted clock observations
#define GT_CLOCK_CONFIRM    3       // identical observations to adopt / mismatches to block / off-grid PC clock to alert
#define GT_FLOW_PENDING_SEC 60      // a balance / credit change the new deals do not explain waits at most this long
#define GT_FLOW_START_SEC   300     // ... at the first reconciliation after a start / re-init (history may still sync)
#define GT_ABSORB_MAX       5       // changes counted as profit / loss at the limit, kept to recognise a late cash deal
#define GT_ABSORB_KEEP_SEC  604800  // ... for 7 days
#define GT_PRIME_STABLE_SEC 60      // first run: the cash-flow deals of the history unchanged this long = complete
#define GT_PRIME_MAX_SEC    600     // first run: start the cash-flow tracking after this long anyway (warning)
#define GT_LOCK_STALE_SEC   60      // instance lock: heartbeat older than this = holder gone
#define GT_LOCK_BEAT_SEC    10      // instance lock: heartbeat interval
#define GT_REPEAT_SEC       21600   // repeat a standing alert at most every 6 hours
#define GT_STALE_FEED_SEC   600     // no new quote for this long while the market is open = stale feed (Python monitor.stale_feed_minutes 10)
#define GT_SESSION_GRACE_SEC 600    // ... the first quote of a session (Monday, after Dec 25 / Jan 1) may come this late
#define GT_NOTIFY_MAX       30      // push queue length
#define GT_FAR_FUTURE       D'2100.01.01 00:00:00'

//--- globals
CTrade   g_trade;
string   g_sym[];      // broker symbol names (NR)
string   g_base[];     // base names (NR)
datetime g_lastBar[];  // last processed closed M15 bar per NR symbol
bool     g_defOn[];    // NR signal deferred by an entry gate, per NR symbol (retried while its bar is fresh)
MqlRates g_defBar[];   // ... its bar and indicators
double   g_defMid[];
double   g_defUp[];
double   g_defLo[];
double   g_defAtr[];
int      g_nsym = 0;
string   g_esSym = "";
bool     g_esOk = false;
double   g_peak = 0.0;
datetime g_day = 0;
double   g_dayStartEq = 0.0;
bool     g_halted = false;
datetime g_lastESDay = 0;
string   g_gvPrefix = "";
bool     g_tester = false;
datetime g_month = 0;            // market-time month start
double   g_monthStartEq = 0.0;
bool     g_monthHalted = false;
bool     g_dayHalted = false;
double   g_dailyEq[];            // closing equity of past market days (oldest first)
double   g_lastEq = 0.0;
double   g_adaptMult = 1.0;
bool     g_flatten = false;      // set when a hard stop requires closing all positions
string   g_flattenReason = "";
string   g_multSym[];
double   g_multVal[];
int      g_boStart = 0;          // blackout start as month*100+day (0 = off)
int      g_boEnd = 0;

//--- state persistence
bool     g_stateLoaded = false;  // state loaded for this login; SaveState() is a no-op before (failed OnInit safe)
bool     g_stateDirty = false;   // an important value changed: flush the global variables to disk now
datetime g_lastFlush = 0;
bool     g_gvWritten = false;    // a global variable was written since the last flush
bool     g_gvRefresh = false;    // rewrite every value this time (manual deletion / 4-week expiry)
datetime g_gvRefreshAt = 0;
string   g_gvName[];             // every persisted value: global variable name, key, current value and whether
string   g_gvKey[];              // ... the global variable holds it (written only on change or a full refresh)
double   g_gvVal[];
bool     g_gvOk[];
long     g_stateLogin = 0;       // account of the loaded state (state file name)
bool     g_fileDirty = false;    // a persisted value changed since the state file was last written
datetime g_fileNote = 0;         // last 'state file cannot be written' notice
bool     g_resetHaltDone = false; // InpResetHalt already applied (persisted; re-armed when InpResetHalt=false)
bool     g_resetDue = false;     // InpResetHalt is evaluated after the first cash-flow scan of the session

//--- cash flows (deposits / withdrawals / credit / bonus): amount-based reconciliation (shared rule with Python)
ulong    g_flowTicket = 0;       // newest cash-flow deal ticket applied or marked as seen (persisted "flowtk")
datetime g_flowScan = 0;         // server time the reconciliation reference last moved (persisted "flowtm"; the
                                 // history window of a state of an earlier 1.2 build without a reference)
bool     g_refKnown = false;     // a reconciliation reference exists (persisted "flowmref" / "flowdref" / "flowdtm")
double   g_moneyRef = 0.0;       // balance + credit at the last reconciliation
ulong    g_dealRef = 0;          // newest deal (any type) included in the last reconciliation
datetime g_dealRefTime = 0;      // ... its time (start of the history window)
double   g_absAmt[];             // changes counted as profit / loss at the pending limit (persisted "absa<i>")
datetime g_absTime[];            // ... server time when they were counted (persisted "abst<i>"), oldest first
datetime g_pendingSince = 0;     // local time when the current unexplained change was first seen
int      g_pendingWin = 0;       // ... its limit: GT_FLOW_PENDING_SEC, or GT_FLOW_START_SEC after a start
bool     g_firstRecon = true;    // the first reconciliation after a start / re-init has not happened yet
bool     g_histBad = false;      // this cycle: the deal history cannot be read (no new entry)
bool     g_flowPending = false;  // this cycle: balance change not explained yet (no guard decision, no entry)
bool     g_flowPrimed = true;    // false on a first run until the existing deals are marked as seen
datetime g_primeStart = 0;       // first run: local time of the first priming attempt
datetime g_primeRefAt = 0;       // first run: since when the cash-flow deals below are unchanged
int      g_primeRefN = 0;        // ... their number, ticket sum and ticket xor (a fingerprint of the set)
ulong    g_primeRefSum = 0;
ulong    g_primeRefXor = 0;
datetime g_primeNote = 0;        // ... last 'history cannot be read' alert
datetime g_primeTry = 0;         // ... last priming attempt (the whole history is read at most every 5 s)

//--- broker clock
ENUM_GT_SERVER_TIME g_clockMode = GT_SERVER_NY7; // effective mode (AUTO -> NY7 in the tester)
long     g_clkOffset = 0;        // AUTO: adopted server - UTC offset in seconds (persisted "clkoff")
bool     g_clkHave = false;      // AUTO: an adopted offset exists
bool     g_clkNY7 = false;       // AUTO: the adopted offset matched the NY7 rule: the clock follows US DST ("clkny7")
bool     g_clkVerified = false;  // a valid observation confirmed the clock since start-up
bool     g_clkBlocked = false;   // repeated mismatches: new entries blocked
int      g_clkMismatch = 0;      // consecutive observations that disagree with the clock in use
long     g_clkCand = 0;          // AUTO: candidate new offset
int      g_clkCandN = 0;         // AUTO: consecutive identical observations of the candidate
datetime g_clkLastObs = 0;       // local time of the last counted observation
datetime g_lastSrvSeen = 0;      // newest TimeCurrent() seen
datetime g_srvAdvAt = 0;         // local time when TimeCurrent() last advanced
datetime g_lastSrvSeenAt = 0;    // local time when g_lastSrvSeen was first seen (TrackServerTime)
int      g_clkOffGridN = 0;      // consecutive fresh observations off the half-hour grid (PC clock off)
long     g_clkOffGridSec = 0;    // ... seconds off the grid at the last one
datetime g_clkDriftNote = 0;     // local time of the last PC clock alert

//--- monitoring
datetime g_ddAlertDay = 0;       // market day of the last drawdown alert (persisted "ddalert")
bool     g_sumPending = false;   // a market day ended: send the daily summary
datetime g_sumDay = 0;
double   g_sumMonthRet = 0.0;
int      g_permit = -1;          // -1 unknown, 0 trading blocked, 1 trading permitted
datetime g_permitNote = 0;
datetime g_discSince = 0;
bool     g_discNotified = false;
datetime g_discNote = 0;
bool     g_staleNotified = false;
datetime g_staleNote = 0;
datetime g_startLocal = 0;
string   g_capSym[];             // lot-cap notices: once per market day per symbol
datetime g_capDay[];
ulong    g_noSLTk[];             // own positions without a stop loss already notified ...
datetime g_noSLNote[];           // ... and when (at most every GT_REPEAT_SEC per ticket; pruned in PruneFails)

//--- close back-off (bounded by the open positions, see PruneFails)
ulong    g_failTk[];
datetime g_failNext[];
datetime g_failNote[];

//--- push notifications (MT5 accepts at most 2 per second and 10 per minute)
string   g_nq[];
datetime g_lastPush = 0;

//--- single instance per account (terminal global variable GT_<login>_lock + heartbeat GT_<login>_lockhb)
double   g_lockToken = 0.0;
bool     g_lockHeld = false;
long     g_lockLogin = 0;
datetime g_lockBeat = 0;
bool     g_stopping = false;     // ExpertRemove() requested: ignore the remaining events

//+------------------------------------------------------------------+
//| Small helpers                                                     |
//+------------------------------------------------------------------+
long Secs(const datetime a, const datetime b)
  {
   return (long)a - (long)b;
  }

//+------------------------------------------------------------------+
//| Notifications and log                                             |
//+------------------------------------------------------------------+
void Notify(const string msg)
  {
   if(!InpPushNotify || g_tester)
      return;
   int n = ArraySize(g_nq);
   if(n >= GT_NOTIFY_MAX)
     {
      g_nq[n - 1] = "(more messages in the Experts log)";
      return;
     }
   ArrayResize(g_nq, n + 1);
   g_nq[n] = msg;
  }

// merges queued messages into one push of at most 255 characters, at most every 6 seconds
void FlushNotify(const bool force = false)
  {
   int n = ArraySize(g_nq);
   if(n == 0)
      return;
   if(!force && Secs(TimeLocal(), g_lastPush) < 6 && Secs(TimeLocal(), g_lastPush) >= 0)
      return;
   string m = "[GT] ";
   int used = 0;
   for(int i = 0; i < n; i++)
     {
      if(used > 0 && StringLen(m) + StringLen(g_nq[i]) + 3 > 255)
         break;
      if(used > 0)
         m += " | ";
      m += g_nq[i];
      used++;
     }
   if(!SendNotification(StringSubstr(m, 0, 255)))
      Print("[GT] push notification failed (error ", GetLastError(), ")");
   g_lastPush = TimeLocal();
   ArrayRemove(g_nq, 0, used);
  }

void Log(const string msg, const bool notify = false)
  {
   Print("[GT] ", msg);
   if(notify)
      Notify(msg);
  }

//+------------------------------------------------------------------+
//| Time utilities (US DST rules, identical to Python timeutil.py)    |
//+------------------------------------------------------------------+
datetime MakeDate(const int y, const int m, const int d)
  {
   MqlDateTime s;
   s.year = y; s.mon = m; s.day = d; s.hour = 0; s.min = 0; s.sec = 0;
   s.day_of_week = 0; s.day_of_year = 0;
   return StructToTime(s);
  }

datetime NthSunday(const int y, const int m, const int n)
  {
   datetime first = MakeDate(y, m, 1);
   MqlDateTime s;
   TimeToStruct(first, s);
   int add = (7 - s.day_of_week) % 7;          // day_of_week: 0 = Sunday
   return first + (add + 7 * (n - 1)) * 86400;
  }

datetime LastSunday(const int y, const int m)
  {
   int ny = (m == 12) ? y + 1 : y;
   int nm = (m == 12) ? 1 : m + 1;
   datetime last = MakeDate(ny, nm, 1) - 86400;
   MqlDateTime s;
   TimeToStruct(last, s);
   return last - s.day_of_week * 86400;
  }

bool IsUSDST(const datetime utc)
  {
   MqlDateTime s;
   TimeToStruct(utc, s);
   datetime st, en;
   if(s.year >= 2007)
     {
      st = NthSunday(s.year, 3, 2) + 7 * 3600;
      en = NthSunday(s.year, 11, 1) + 6 * 3600;
     }
   else
     {
      st = NthSunday(s.year, 4, 1) + 7 * 3600;
      en = LastSunday(s.year, 10) + 6 * 3600;
     }
   return (utc >= st && utc < en);
  }

// server time -> UTC with the NY7 rule (server time = market time: UTC+3 in US summer, UTC+2 otherwise)
datetime NY7ServerToUTC(const datetime srv)
  {
   datetime cand = srv - 3 * 3600;
   if(IsUSDST(cand))
      return cand;
   return srv - 2 * 3600;
  }

// server - UTC in seconds under the NY7 rule at server time srv
long NY7Offset(const datetime srv)
  {
   return (long)srv - (long)NY7ServerToUTC(srv);
  }

// server time -> UTC with the clock in use. AUTO: an adopted offset that matched the NY7 rule is kept as the NY7
// rule (follows US DST, like Python's detect_server_mode); any other adopted offset is a fixed number of seconds;
// the NY7 rule until one exists. Entries stay blocked until a live observation confirms the clock (CheckClock).
datetime ServerToUTC(const datetime srv)
  {
   if(g_clockMode == GT_SERVER_FIXED)
      return srv - (int)MathRound(InpServerGMTOffset * 3600.0);
   if(g_clockMode == GT_SERVER_AUTO && g_clkHave && !g_clkNY7)
      return (datetime)((long)srv - g_clkOffset);
   return NY7ServerToUTC(srv);
  }

datetime UTCToMarket(const datetime utc)
  {
   return utc + (IsUSDST(utc) ? 3 : 2) * 3600;
  }

datetime ServerToMarket(const datetime srv)
  {
   if(g_clockMode == GT_SERVER_NY7 || (g_clockMode == GT_SERVER_AUTO && (!g_clkHave || g_clkNY7)))
      return srv;
   return UTCToMarket(ServerToUTC(srv));
  }

// the clock in use, for log and status texts
string ClockText()
  {
   if(g_clockMode == GT_SERVER_FIXED)
      return StringFormat("fixed UTC%+.1f h", InpServerGMTOffset);
   if(g_clockMode == GT_SERVER_AUTO && g_clkHave && !g_clkNY7)
      return StringFormat("UTC%+.1f h (fixed)", g_clkOffset / 3600.0);
   return "NY7 rule (UTC+3 in US summer, UTC+2 otherwise)";
  }

datetime DayStart(const datetime t)
  {
   return t - (t % 86400);
  }

datetime Floor15(const datetime t)
  {
   return t - (t % 900);
  }

//+------------------------------------------------------------------+
//| Symbol helpers                                                    |
//+------------------------------------------------------------------+
double PipSize(const string base, const int digits)
  {
   if(StringFind(base, "XAU") == 0)
      return 0.1;
   if(StringSubstr(base, 3, 3) == "JPY")
      return 0.01;
   if(digits == 2 || digits == 3)
      return 0.01;
   return 0.0001;
  }

string BaseOf(const string sym)
  {
   return StringSubstr(sym, 0, 6);
  }

double SymPip(const string sym)
  {
   return PipSize(BaseOf(sym), (int)SymbolInfoInteger(sym, SYMBOL_DIGITS));
  }

//+------------------------------------------------------------------+
//| Risk state (persisted in terminal global variables GT_<login>_*)  |
//+------------------------------------------------------------------+
// records a persisted value (state file mirror) and writes its global variable only when it differs from the value
// last written successfully (or on a full refresh)
void GVPut(const string key, const double v)
  {
   string name = g_gvPrefix + key;
   int n = ArraySize(g_gvName);
   int idx = -1;
   for(int i = 0; i < n; i++)
      if(g_gvName[i] == name)
        {
         idx = i;
         break;
        }
   if(idx < 0)
     {
      idx = n;
      ArrayResize(g_gvName, n + 1);
      ArrayResize(g_gvKey, n + 1);
      ArrayResize(g_gvVal, n + 1);
      ArrayResize(g_gvOk, n + 1);
      g_gvName[idx] = name;
      g_gvKey[idx] = key;
      g_gvVal[idx] = v;
      g_gvOk[idx] = false;
      g_fileDirty = true;
     }
   else
      if(g_gvVal[idx] != v)
        {
         g_gvVal[idx] = v;
         g_gvOk[idx] = false;
         g_fileDirty = true;
        }
      else
         if(g_gvOk[idx] && !g_gvRefresh)
            return;
   if(GlobalVariableSet(name, v) == 0)
     {
      Print("[GT] could not write global variable ", name, " (error ", GetLastError(), ")");
      return;   // tried again at the next save
     }
   g_gvOk[idx] = true;
   g_gvWritten = true;
  }

//+------------------------------------------------------------------+
//| State file: mirror of the global variables (4-week expiry)        |
//+------------------------------------------------------------------+
// MT5 deletes a terminal global variable 4 weeks after its last access. Every persisted value is mirrored to
// MQL5\Files\GreatestTrader_<login>.state (ASCII key=value lines, written atomically: a temporary file, then
// FileMove with FILE_REWRITE) whenever the state is flushed after a change, and at the hourly full refresh. When
// the global variables of the account are missing at a start, the file of the same login restores them (notified).
// Never in the Strategy Tester.
string StateFileName(const long login)
  {
   return "GreatestTrader_" + IntegerToString(login) + ".state";
  }

void StateFileProblem(const string msg)
  {
   datetime now = TimeLocal();
   if(g_fileNote != 0 && Secs(now, g_fileNote) < GT_REPEAT_SEC && Secs(now, g_fileNote) >= 0)
     {
      if(InpVerbose)
         Log(msg);
      return;   // logged and notified at most every GT_REPEAT_SEC; tried again at every flush
     }
   g_fileNote = now;
   Log(msg + " - the state is still kept in the terminal global variables", true);
  }

bool WriteStateFile()
  {
   if(g_tester || g_stateLogin <= 0)
      return false;
   string fn = StateFileName(g_stateLogin);
   string tmp = fn + ".tmp";
   string s = "# GreatestTrader EA state: mirror of the terminal global variables " + g_gvPrefix + "*\r\n";
   s += "# saved " + TimeToString(TimeLocal(), TIME_DATE | TIME_SECONDS) + " (local time)\r\n";
   s += "login=" + IntegerToString(g_stateLogin) + "\r\n";
   for(int i = 0; i < ArraySize(g_gvKey); i++)
      s += g_gvKey[i] + "=" + DoubleToString(g_gvVal[i], 8) + "\r\n";
   ResetLastError();
   int h = FileOpen(tmp, FILE_WRITE | FILE_TXT | FILE_ANSI);
   if(h == INVALID_HANDLE)
     {
      StateFileProblem(StringFormat("state file %s cannot be written (error %d)", tmp, GetLastError()));
      return false;
     }
   uint written = FileWriteString(h, s);
   FileClose(h);
   if(written == 0)
     {
      StateFileProblem(StringFormat("state file %s cannot be written (error %d)", tmp, GetLastError()));
      FileDelete(tmp);
      return false;
     }
   ResetLastError();
   if(!FileMove(tmp, 0, fn, FILE_REWRITE))
     {
      StateFileProblem(StringFormat("state file %s cannot be replaced (error %d)", fn, GetLastError()));
      FileDelete(tmp);
      return false;
     }
   g_fileDirty = false;
   return true;
  }

// a key of the state file: lower-case letters and digits only
bool IsStateKey(const string k)
  {
   int n = StringLen(k);
   if(n < 1 || n > 20)
      return false;
   for(int i = 0; i < n; i++)
     {
      ushort c = StringGetCharacter(k, i);
      if(!((c >= 'a' && c <= 'z') || (c >= '0' && c <= '9')))
         return false;
     }
   return true;
  }

// a value of the state file: optional '-', digits, at most one '.'
bool IsStateNumber(const string v)
  {
   int n = StringLen(v);
   int start = (n > 0 && StringGetCharacter(v, 0) == '-') ? 1 : 0;
   int digits = 0, dots = 0;
   for(int i = start; i < n; i++)
     {
      ushort c = StringGetCharacter(v, i);
      if(c >= '0' && c <= '9')
         digits++;
      else
         if(c == '.')
            dots++;
         else
            return false;
     }
   return (digits > 0 && dots <= 1);
  }

// the global variables of the account are missing (4-week expiry or deleted): restores them from the state file of
// the same login, before LoadState. Returns true when restored.
bool RestoreStateFile(const long login)
  {
   string fn = StateFileName(login);
   if(!FileIsExist(fn))
      return false;
   ResetLastError();
   int h = FileOpen(fn, FILE_READ | FILE_TXT | FILE_ANSI);
   if(h == INVALID_HANDLE)
     {
      Log(StringFormat("the terminal global variables %s* are missing and the state file %s cannot be read (error "
                       "%d): the EA starts with a fresh state", g_gvPrefix, fn, GetLastError()), true);
      return false;
     }
   string keys[];
   double vals[];
   int n = 0;
   long fileLogin = -1;
   bool hasPeak = false;
   string saved = "?";
   while(!FileIsEnding(h))
     {
      string line = FileReadString(h);
      StringTrimLeft(line);
      StringTrimRight(line);
      if(StringLen(line) == 0)
         continue;
      if(StringGetCharacter(line, 0) == '#')
        {
         if(StringFind(line, "# saved ") == 0)
            saved = StringSubstr(line, 8);
         continue;
        }
      int p = StringFind(line, "=");
      if(p <= 0)
         continue;
      string k = StringSubstr(line, 0, p);
      string v = StringSubstr(line, p + 1);
      if(k == "login")
        {
         fileLogin = StringToInteger(v);
         continue;
        }
      if(!IsStateKey(k) || !IsStateNumber(v) || n >= 2000)
         continue;
      ArrayResize(keys, n + 1);
      ArrayResize(vals, n + 1);
      keys[n] = k;
      vals[n] = StringToDouble(v);
      if(k == "peak")
         hasPeak = true;
      n++;
     }
   FileClose(h);
   if(fileLogin != login || !hasPeak)
     {
      Log(StringFormat("state file %s ignored (account %s, peak %s): the EA starts with a fresh state", fn,
                       IntegerToString(fileLogin), hasPeak ? "present" : "missing"), true);
      return false;
     }
   for(int i = 0; i < n; i++)
      GlobalVariableSet(g_gvPrefix + keys[i], vals[i]);
   GlobalVariablesFlush();
   Log(StringFormat("state RESTORED from MQL5\\Files\\%s (saved %s, %d values): the terminal global variables %s* "
                    "were missing (MT5 deletes them 4 weeks after their last access, or they were deleted). To start "
                    "with a fresh state, delete this file as well.", fn, saved, n, g_gvPrefix), true);
   return true;
  }

void SaveState(const bool force = false)
  {
   if(g_tester || !g_stateLoaded)
      return;   // never overwrite the persisted state with unloaded defaults (e.g. OnDeinit after a failed OnInit)
   datetime now = TimeLocal();
   g_gvRefresh = (force || now >= g_gvRefreshAt);
   if(g_gvRefresh)
     {
      g_gvRefreshAt = now + 3600;
      g_fileDirty = true;   // the state file is rewritten at the full refresh too (deleted by hand meanwhile?)
     }
   GVPut("peak", g_peak);
   GVPut("day", (double)g_day);
   GVPut("dayeq", g_dayStartEq);
   GVPut("halt", g_halted ? 1.0 : 0.0);
   GVPut("esday", (double)g_lastESDay);
   GVPut("month", (double)g_month);
   GVPut("montheq", g_monthStartEq);
   GVPut("monthhalt", g_monthHalted ? 1.0 : 0.0);
   GVPut("dayhalt", g_dayHalted ? 1.0 : 0.0);
   GVPut("lasteq", g_lastEq);
   int n = ArraySize(g_dailyEq);
   GVPut("deqn", (double)n);
   for(int i = 0; i < n; i++)
      GVPut("deq" + IntegerToString(i), g_dailyEq[i]);
   if(g_flowPrimed)
     {
      // only a primed cursor is persisted: a restart before the first-run priming primes again
      GVPut("flowtk", (double)g_flowTicket);   // deal tickets are far below 2^53: exact in a double
      GVPut("flowtm", (double)g_flowScan);
      if(g_refKnown)
        {
         // the reconciliation reference: a restart reconciles against it like a running cycle
         GVPut("flowmref", g_moneyRef);
         GVPut("flowdref", (double)g_dealRef);
         GVPut("flowdtm", (double)g_dealRefTime);
        }
      int na = ArraySize(g_absAmt);
      GVPut("absn", (double)na);
      for(int i = 0; i < na; i++)
        {
         GVPut("absa" + IntegerToString(i), g_absAmt[i]);
         GVPut("abst" + IntegerToString(i), (double)g_absTime[i]);
        }
     }
   if(g_clkHave)
     {
      GVPut("clkoff", (double)g_clkOffset);
      GVPut("clkny7", g_clkNY7 ? 1.0 : 0.0);
     }
   GVPut("ddalert", (double)g_ddAlertDay);
   GVPut("rsthalt", g_resetHaltDone ? 1.0 : 0.0);
   g_gvRefresh = false;
   // the terminal writes gvariables.dat only at a clean exit: flush so that a VPS crash cannot roll the
   // peak / halt / month stop back to old values
   if(force || g_stateDirty || (g_gvWritten && Secs(now, g_lastFlush) >= 60) || Secs(now, g_lastFlush) < 0)
     {
      GlobalVariablesFlush();
      g_lastFlush = now;
      g_stateDirty = false;
      g_gvWritten = false;
      if(g_fileDirty)
         WriteStateFile();   // the 4-week-expiry mirror, at most as often as the global variables are flushed
     }
  }

void ResetStateVars()
  {
   g_peak = 0.0;
   g_day = 0;
   g_dayStartEq = 0.0;
   g_halted = false;
   g_lastESDay = 0;
   g_month = 0;
   g_monthStartEq = 0.0;
   g_monthHalted = false;
   g_dayHalted = false;
   g_lastEq = 0.0;
   ArrayResize(g_dailyEq, 0);
   g_adaptMult = 1.0;
   g_flowTicket = 0;
   g_flowScan = 0;
   g_refKnown = false;
   g_moneyRef = 0.0;
   g_dealRef = 0;
   g_dealRefTime = 0;
   ArrayResize(g_absAmt, 0);
   ArrayResize(g_absTime, 0);
   g_pendingSince = 0;
   g_pendingWin = 0;
   g_firstRecon = true;
   g_histBad = false;
   g_flowPending = false;
   g_flowPrimed = true;
   g_primeStart = 0;
   g_primeRefAt = 0;
   g_primeRefN = 0;
   g_primeRefSum = 0;
   g_primeRefXor = 0;
   g_primeNote = 0;
   g_primeTry = 0;
   g_clkHave = false;
   g_clkOffset = 0;
   g_clkNY7 = false;
   g_ddAlertDay = 0;
   g_resetHaltDone = false;
   g_resetDue = false;
   g_sumPending = false;
  }

// every key is optional: state written by v1.1 (no flow / clock / alert keys) loads unchanged
void LoadState()
  {
   if(GlobalVariableCheck(g_gvPrefix + "peak"))
      g_peak = GlobalVariableGet(g_gvPrefix + "peak");
   if(GlobalVariableCheck(g_gvPrefix + "day"))
      g_day = (datetime)GlobalVariableGet(g_gvPrefix + "day");
   if(GlobalVariableCheck(g_gvPrefix + "dayeq"))
      g_dayStartEq = GlobalVariableGet(g_gvPrefix + "dayeq");
   if(GlobalVariableCheck(g_gvPrefix + "halt"))
      g_halted = (GlobalVariableGet(g_gvPrefix + "halt") > 0.5);
   if(GlobalVariableCheck(g_gvPrefix + "esday"))
      g_lastESDay = (datetime)GlobalVariableGet(g_gvPrefix + "esday");
   if(GlobalVariableCheck(g_gvPrefix + "month"))
      g_month = (datetime)GlobalVariableGet(g_gvPrefix + "month");
   if(GlobalVariableCheck(g_gvPrefix + "montheq"))
      g_monthStartEq = GlobalVariableGet(g_gvPrefix + "montheq");
   if(GlobalVariableCheck(g_gvPrefix + "monthhalt"))
      g_monthHalted = (GlobalVariableGet(g_gvPrefix + "monthhalt") > 0.5);
   if(GlobalVariableCheck(g_gvPrefix + "dayhalt"))
      g_dayHalted = (GlobalVariableGet(g_gvPrefix + "dayhalt") > 0.5);
   if(GlobalVariableCheck(g_gvPrefix + "lasteq"))
      g_lastEq = GlobalVariableGet(g_gvPrefix + "lasteq");
   if(GlobalVariableCheck(g_gvPrefix + "deqn"))
     {
      int n = (int)GlobalVariableGet(g_gvPrefix + "deqn");
      ArrayResize(g_dailyEq, 0);
      for(int i = 0; i < n; i++)
        {
         string name = g_gvPrefix + "deq" + IntegerToString(i);
         if(!GlobalVariableCheck(name))
            break;
         int k = ArraySize(g_dailyEq);
         ArrayResize(g_dailyEq, k + 1);
         g_dailyEq[k] = GlobalVariableGet(name);
        }
     }
   if(GlobalVariableCheck(g_gvPrefix + "flowtk"))
      g_flowTicket = (ulong)GlobalVariableGet(g_gvPrefix + "flowtk");
   if(GlobalVariableCheck(g_gvPrefix + "flowtm"))
      g_flowScan = (datetime)GlobalVariableGet(g_gvPrefix + "flowtm");
   // reconciliation reference (missing in a state of an earlier 1.2 build: taken from the first read, no priming)
   if(GlobalVariableCheck(g_gvPrefix + "flowmref") && GlobalVariableCheck(g_gvPrefix + "flowdref"))
     {
      g_moneyRef = GlobalVariableGet(g_gvPrefix + "flowmref");
      g_dealRef = (ulong)GlobalVariableGet(g_gvPrefix + "flowdref");
      if(GlobalVariableCheck(g_gvPrefix + "flowdtm"))
         g_dealRefTime = (datetime)GlobalVariableGet(g_gvPrefix + "flowdtm");
      g_refKnown = true;
     }
   if(GlobalVariableCheck(g_gvPrefix + "absn"))
     {
      int na = (int)GlobalVariableGet(g_gvPrefix + "absn");
      if(na > GT_ABSORB_MAX)
         na = GT_ABSORB_MAX;
      for(int i = 0; i < na; i++)
        {
         string an = g_gvPrefix + "absa" + IntegerToString(i);
         string tn = g_gvPrefix + "abst" + IntegerToString(i);
         if(!GlobalVariableCheck(an) || !GlobalVariableCheck(tn))
            break;
         int k = ArraySize(g_absAmt);
         ArrayResize(g_absAmt, k + 1);
         ArrayResize(g_absTime, k + 1);
         g_absAmt[k] = GlobalVariableGet(an);
         g_absTime[k] = (datetime)GlobalVariableGet(tn);
        }
     }
   if(GlobalVariableCheck(g_gvPrefix + "clkoff"))
     {
      long off = (long)MathRound(GlobalVariableGet(g_gvPrefix + "clkoff"));
      if(off >= -14 * 3600 && off <= 14 * 3600)
        {
         g_clkOffset = off;
         g_clkHave = true;
         if(GlobalVariableCheck(g_gvPrefix + "clkny7"))
            g_clkNY7 = (GlobalVariableGet(g_gvPrefix + "clkny7") > 0.5);
         else
           {
            // state of an earlier build (a number only): an offset equal to the current NY7 offset is the NY7 rule
            datetime srv = TimeCurrent();
            long ny7 = (srv > 0) ? NY7Offset(srv) : (long)(IsUSDST(TimeGMT()) ? 3 : 2) * 3600;
            g_clkNY7 = (off == ny7);
           }
        }
     }
   if(GlobalVariableCheck(g_gvPrefix + "ddalert"))
      g_ddAlertDay = (datetime)GlobalVariableGet(g_gvPrefix + "ddalert");
   if(GlobalVariableCheck(g_gvPrefix + "rsthalt"))
      g_resetHaltDone = (GlobalVariableGet(g_gvPrefix + "rsthalt") > 0.5);
   g_adaptMult = AdaptiveMult();
  }

double BaseRisk(const bool isNR)
  {
   switch(InpRiskProfile)
     {
      case GT_RISK_CONSERVATIVE:
         return 0.005;
      case GT_RISK_STANDARD:
         return 0.010;
      case GT_RISK_AGGRESSIVE:
         return 0.015;
      default:
         return (isNR ? InpRiskNR : InpRiskES) / 100.0;
     }
  }

double Drawdown(const double eq)
  {
   if(g_peak <= 0.0)
      return 0.0;
   return MathMax(0.0, 1.0 - eq / g_peak);
  }

double RiskFraction(const bool isNR, const double eq)
  {
   double mult = 1.0;
   if(InpDDScaleFull > 0.0)
      mult = MathMax(InpDDScaleFloor, 1.0 - Drawdown(eq) / (InpDDScaleFull / 100.0));
   return BaseRisk(isNR) * mult * g_adaptMult;
  }

// volatility-target and equity-curve multipliers (identical to Python RiskManager)
double AdaptiveMult()
  {
   double mult = 1.0;
   int n = ArraySize(g_dailyEq);
   int minDays = (InpVolLookbackDays / 2 > 5) ? InpVolLookbackDays / 2 : 5;
   if(InpVolTargetDaily > 0.0 && n >= minDays)
     {
      int first = (int)MathMax(0, n - (InpVolLookbackDays + 1));
      double rets[];
      int m = 0;
      for(int i = first + 1; i < n; i++)
        {
         if(g_dailyEq[i - 1] <= 0.0)
            continue;
         ArrayResize(rets, m + 1);
         rets[m] = g_dailyEq[i] / g_dailyEq[i - 1] - 1.0;
         m++;
        }
      if(m >= 2)
        {
         double mu = 0.0;
         for(int i = 0; i < m; i++)
            mu += rets[i];
         mu /= m;
         double var = 0.0;
         for(int i = 0; i < m; i++)
            var += (rets[i] - mu) * (rets[i] - mu);
         double sd = MathSqrt(var / (m - 1));
         if(sd > 0.0)
            mult *= MathMin(InpVolMultMax, MathMax(InpVolMultMin, (InpVolTargetDaily / 100.0) / sd));
        }
     }
   if(InpEqFilterDays > 0 && n >= InpEqFilterDays)
     {
      double sum = 0.0;
      for(int i = n - InpEqFilterDays; i < n; i++)
         sum += g_dailyEq[i];
      if(g_dailyEq[n - 1] < sum / InpEqFilterDays)
         mult *= InpEqFilterMult;
     }
   return mult;
  }

datetime MonthStart(const datetime t)
  {
   MqlDateTime s;
   TimeToStruct(t, s);
   return MakeDate(s.year, s.mon, 1);
  }

void UpdateEquityState(const double eq, const datetime nowSrv)
  {
   g_flatten = false;
   g_flattenReason = "";
   if(eq <= 0.0)
      return;   // an equity reading of 0 (terminal not ready) must never set a halt, a stop or a baseline
   if(eq > g_peak)
      g_peak = eq;
   datetime mday = DayStart(ServerToMarket(nowSrv));
   MqlDateTime ms;
   TimeToStruct(mday, ms);
   if(ms.day_of_week == 0 || ms.day_of_week == 6)
     {
      // market days are Monday to Friday (shared rule with the Python engine): a Saturday / Sunday market date
      // (an unconfirmed broker clock change around a DST switch, weekend quotes) keeps the current market day and
      // month - no daily summary, daily equity point or day-stop reference for a weekend day
      if(g_day != 0)
         mday = g_day;
      else
         mday -= (ms.day_of_week == 6 ? 1 : 2) * 86400;   // first run on a weekend: the Friday before
     }
   if(mday != g_day)
     {
      if(g_day != 0 && g_lastEq > 0.0)
        {
         int n = ArraySize(g_dailyEq);
         ArrayResize(g_dailyEq, n + 1);
         g_dailyEq[n] = g_lastEq;
         int keep = ((InpVolLookbackDays > InpEqFilterDays) ? InpVolLookbackDays : InpEqFilterDays) + 2;
         int sz = ArraySize(g_dailyEq);
         if(sz > keep)
           {
            double tmp[];
            ArrayResize(tmp, keep);
            for(int i = 0; i < keep; i++)
               tmp[i] = g_dailyEq[sz - keep + i];
            ArrayResize(g_dailyEq, keep);
            for(int i = 0; i < keep; i++)
               g_dailyEq[i] = tmp[i];
           }
        }
      if(g_day != 0)
        {
         // daily summary of the market day that just ended (sent from ProcessAll, live only)
         g_sumPending = true;
         g_sumDay = g_day;
         g_sumMonthRet = (g_monthStartEq > 0.0) ? eq / g_monthStartEq - 1.0 : 0.0;
        }
      g_day = mday;
      g_dayStartEq = eq;
      g_dayHalted = false;
      g_adaptMult = AdaptiveMult();
      g_stateDirty = true;
     }
   g_lastEq = eq;
   datetime mmon = MonthStart(mday);
   if(mmon != g_month)
     {
      g_month = mmon;
      g_monthStartEq = eq;
      g_monthHalted = false;
      g_stateDirty = true;
     }
   double dd = Drawdown(eq);
   if(!g_halted && InpMaxDDHalt > 0.0 && dd * 100.0 >= InpMaxDDHalt)
     {
      g_halted = true;
      g_stateDirty = true;
      Log(StringFormat("HALT: drawdown %.1f%% reached (limit %.1f%%). New entries stopped; closes and stops keep working. "
                       "To resume set InpResetHalt=true once (other state is kept).", dd * 100.0, InpMaxDDHalt), true);
     }
   if(InpMonthlyHardStop > 0.0 && !g_monthHalted && g_monthStartEq > 0.0 &&
      eq <= g_monthStartEq * (1.0 - InpMonthlyHardStop / 100.0))
     {
      g_monthHalted = true;
      g_flatten = true;
      g_stateDirty = true;
      g_flattenReason = StringFormat("monthly hard stop %.1f%%", InpMonthlyHardStop);
      Log("MONTH STOP: " + g_flattenReason, true);
     }
   if(InpDailyHardStop > 0.0 && !g_dayHalted && g_dayStartEq > 0.0 &&
      eq <= g_dayStartEq * (1.0 - InpDailyHardStop / 100.0))
     {
      g_dayHalted = true;
      g_flatten = true;
      g_stateDirty = true;
      if(g_flattenReason == "")
         g_flattenReason = StringFormat("daily hard stop %.1f%%", InpDailyHardStop);
      Log(StringFormat("DAY STOP: daily hard stop %.1f%%", InpDailyHardStop), true);
     }
  }

double SymbolMult(const string sym)
  {
   string b = BaseOf(sym);
   for(int i = 0; i < ArraySize(g_multSym); i++)
      if(g_multSym[i] == b)
         return g_multVal[i];
   return 1.0;
  }

bool IsPlainNumber(string v)
  {
   StringTrimLeft(v);
   StringTrimRight(v);
   int digits = 0, dots = 0;
   for(int i = 0; i < StringLen(v); i++)
     {
      ushort c = StringGetCharacter(v, i);
      if(c >= '0' && c <= '9')
         digits++;
      else
         if(c == '.')
            dots++;
         else
            return false;
     }
   return (digits > 0 && dots <= 1);
  }

// returns false (and prints the item) when an item is not SYMBOL:number
bool ParseSymbolMult()
  {
   ArrayResize(g_multSym, 0);
   ArrayResize(g_multVal, 0);
   string items[];
   int n = StringSplit(InpSymbolRiskMult, ',', items);
   for(int i = 0; i < n; i++)
     {
      string item = items[i];
      StringTrimLeft(item);
      StringTrimRight(item);
      if(StringLen(item) == 0)
         continue;
      string kv[];
      if(StringSplit(item, ':', kv) != 2 || !IsPlainNumber(kv[1]))
        {
         Print("[GT] InpSymbolRiskMult: invalid item '", item, "' (expected SYMBOL:number, e.g. EURJPY:0.25)");
         return false;
        }
      string k = kv[0];
      StringTrimLeft(k);
      StringTrimRight(k);
      StringToUpper(k);
      k = StringSubstr(k, 0, 6);   // base name: a key typed with the broker suffix still matches
      int m = ArraySize(g_multSym);
      ArrayResize(g_multSym, m + 1);
      ArrayResize(g_multVal, m + 1);
      g_multSym[m] = k;
      string v = kv[1];
      StringTrimLeft(v);
      StringTrimRight(v);
      g_multVal[m] = StringToDouble(v);
     }
   return true;
  }

int ParseMMDD(const string v)
  {
   string parts[];
   if(StringSplit(v, '-', parts) != 2)
      return 0;
   int m = (int)StringToInteger(parts[0]);
   int d = (int)StringToInteger(parts[1]);
   if(m < 1 || m > 12 || d < 1 || d > 31)
      return 0;
   return m * 100 + d;
  }

bool InBlackout()
  {
   if(g_boStart == 0 || g_boEnd == 0 || g_day == 0)
      return false;
   MqlDateTime s;
   TimeToStruct(g_day, s);
   int md = s.mon * 100 + s.day;
   if(g_boStart <= g_boEnd)
      return (md >= g_boStart && md <= g_boEnd);
   return (md >= g_boStart || md <= g_boEnd);
  }

void CloseAllOurs(const string reason)
  {
   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      ulong tk = PositionGetTicket(i);
      if(tk == 0)
         continue;
      if(IsOurMagic(PositionGetInteger(POSITION_MAGIC)))
         ClosePos(tk, reason);
     }
  }

bool DailyLimitHit(const double eq)
  {
   if(InpDailyLossLimit <= 0.0 || g_dayStartEq <= 0.0)
      return false;
   return eq <= g_dayStartEq * (1.0 - InpDailyLossLimit / 100.0);
  }

//+------------------------------------------------------------------+
//| Position helpers                                                  |
//+------------------------------------------------------------------+
bool IsOurMagic(const long magic)
  {
   return (magic == InpNRMagic || magic == InpESMagic);
  }

int CountOurPositions()
  {
   int n = 0;
   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      ulong tk = PositionGetTicket(i);
      if(tk == 0)
         continue;
      if(IsOurMagic(PositionGetInteger(POSITION_MAGIC)))
         n++;
     }
   return n;
  }

bool HasPositionOnSymbol(const string sym)
  {
   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      ulong tk = PositionGetTicket(i);
      if(tk == 0)
         continue;
      if(IsOurMagic(PositionGetInteger(POSITION_MAGIC)) && PositionGetString(POSITION_SYMBOL) == sym)
         return true;
     }
   return false;
  }

// a position or an in-flight order of this strategy (magic) on the symbol: used after a timeout / no reply
bool OwnTradeOnSymbol(const string sym, const long magic)
  {
   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      ulong tk = PositionGetTicket(i);
      if(tk == 0)
         continue;
      if(PositionGetInteger(POSITION_MAGIC) == magic && PositionGetString(POSITION_SYMBOL) == sym)
         return true;
     }
   for(int i = OrdersTotal() - 1; i >= 0; i--)
     {
      ulong ot = OrderGetTicket(i);
      if(ot == 0)
         continue;
      if(OrderGetInteger(ORDER_MAGIC) == magic && OrderGetString(ORDER_SYMBOL) == sym)
         return true;
     }
   return false;
  }

int CountCurrency(const string ccy)
  {
   int n = 0;
   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      ulong tk = PositionGetTicket(i);
      if(tk == 0)
         continue;
      if(!IsOurMagic(PositionGetInteger(POSITION_MAGIC)))
         continue;
      string b = BaseOf(PositionGetString(POSITION_SYMBOL));
      if(StringSubstr(b, 0, 3) == ccy || StringSubstr(b, 3, 3) == ccy)
         n++;
     }
   return n;
  }

bool HasESPosition()
  {
   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      ulong tk = PositionGetTicket(i);
      if(tk == 0)
         continue;
      if(PositionGetInteger(POSITION_MAGIC) == InpESMagic)
         return true;
     }
   return false;
  }

// own position without a stop loss: pushed per ticket, at most every GT_REPEAT_SEC (Python key nosl-<ticket>)
void NoSLNotice(const ulong tk, const string sym, const long magic)
  {
   datetime now = TimeLocal();
   int n = ArraySize(g_noSLTk);
   int idx = -1;
   for(int i = 0; i < n; i++)
      if(g_noSLTk[i] == tk)
         idx = i;
   if(idx >= 0 && Secs(now, g_noSLNote[idx]) < GT_REPEAT_SEC && Secs(now, g_noSLNote[idx]) >= 0)
     {
      if(InpVerbose)
         Log(StringFormat("%s ticket=%s has no stop loss: open risk treated as unlimited", sym, IntegerToString((long)tk)));
      return;
     }
   if(idx < 0)
     {
      idx = n;
      ArrayResize(g_noSLTk, n + 1);
      ArrayResize(g_noSLNote, n + 1);
      g_noSLTk[idx] = tk;
     }
   g_noSLNote[idx] = now;
   Log(StringFormat("%s %s ticket=%s has NO stop loss: open risk counts as unlimited, the total-risk cap blocks new "
                    "entries until it has a stop or is closed", (magic == InpNRMagic) ? "NR" : "ES", sym,
                    IntegerToString((long)tk)), true);
  }

// remaining risk (entry to stop, account currency) of the own positions; fail closed: a position without a stop
// loss or whose risk cannot be priced counts as unlimited and fills the total-risk cap
double OpenRiskTotal()
  {
   double total = 0.0;
   bool unlimited = false;
   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      ulong tk = PositionGetTicket(i);
      if(tk == 0)
         continue;
      long magic = PositionGetInteger(POSITION_MAGIC);
      if(!IsOurMagic(magic))
         continue;
      string sym = PositionGetString(POSITION_SYMBOL);
      int dir = (PositionGetInteger(POSITION_TYPE) == POSITION_TYPE_BUY) ? 1 : -1;
      double op = PositionGetDouble(POSITION_PRICE_OPEN);
      double sl = PositionGetDouble(POSITION_SL);
      double vol = PositionGetDouble(POSITION_VOLUME);
      if(sl <= 0.0)
        {
         NoSLNotice(tk, sym, magic);
         unlimited = true;
         continue;
        }
      if((dir > 0 && sl >= op) || (dir < 0 && sl <= op))
         continue;   // stop at or beyond the entry price: no remaining risk
      double l = LossPerLot(sym, dir, op, sl);
      if(l <= 0.0)
        {
         Log("cannot price open risk of " + sym + ": treated as unlimited");
         unlimited = true;
         continue;
        }
      total += l * vol;
     }
   return unlimited ? 1e300 : total;
  }

// an own position without a stop loss while the total-risk cap is on (it blocks every new entry): status texts
bool NoSLBlocks()
  {
   if(InpMaxTotalRisk <= 0.0)
      return false;
   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      ulong tk = PositionGetTicket(i);
      if(tk == 0)
         continue;
      if(IsOurMagic(PositionGetInteger(POSITION_MAGIC)) && PositionGetDouble(POSITION_SL) <= 0.0)
         return true;
     }
   return false;
  }

// number of open positions that are long (sign=+1) or short (sign=-1) the currency ccy
int CountCurrencyDir(const string ccy, const int sign)
  {
   int n = 0;
   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      ulong tk = PositionGetTicket(i);
      if(tk == 0)
         continue;
      if(!IsOurMagic(PositionGetInteger(POSITION_MAGIC)))
         continue;
      int dir = (PositionGetInteger(POSITION_TYPE) == POSITION_TYPE_BUY) ? 1 : -1;
      string b = BaseOf(PositionGetString(POSITION_SYMBOL));
      if(StringSubstr(b, 0, 3) == ccy && dir == sign)
         n++;
      if(StringSubstr(b, 3, 3) == ccy && -dir == sign)
         n++;
     }
   return n;
  }

bool CanOpen(const string sym, const double eq, const int dir, const double newRisk, string &why)
  {
   if(!EntryGateOpen(why))
      return false;
   if(g_halted)
     {
      why = "halted (max drawdown)";
      return false;
     }
   if(InBlackout())
     {
      why = "year-end holiday blackout";
      return false;
     }
   if(g_monthHalted)
     {
      why = "monthly stop";
      return false;
     }
   if(g_dayHalted)
     {
      why = "daily stop";
      return false;
     }
   if(DailyLimitHit(eq))
     {
      why = "daily loss limit";
      return false;
     }
   if(InpMonthlyLossLimit > 0.0 && g_monthStartEq > 0.0 && eq <= g_monthStartEq * (1.0 - InpMonthlyLossLimit / 100.0))
     {
      why = "monthly loss limit";
      return false;
     }
   if(CountOurPositions() >= InpMaxOpen)
     {
      why = "max open positions";
      return false;
     }
   if(HasPositionOnSymbol(sym))
     {
      why = "position already open on symbol";
      return false;
     }
   string b = BaseOf(sym);
   if(CountCurrency(StringSubstr(b, 0, 3)) >= InpMaxPerCurrency || CountCurrency(StringSubstr(b, 3, 3)) >= InpMaxPerCurrency)
     {
      why = "max positions per currency";
      return false;
     }
   if(InpMaxSameDirPerCcy > 0 && dir != 0 &&
      (CountCurrencyDir(StringSubstr(b, 0, 3), dir) >= InpMaxSameDirPerCcy ||
       CountCurrencyDir(StringSubstr(b, 3, 3), -dir) >= InpMaxSameDirPerCcy))
     {
      why = "max same-direction positions per currency";
      return false;
     }
   if(InpMaxTotalRisk > 0.0 && eq > 0.0 && (OpenRiskTotal() + newRisk) / eq > InpMaxTotalRisk / 100.0 + 1e-12)
     {
      why = "max total open risk";
      return false;
     }
   why = "";
   return true;
  }

//+------------------------------------------------------------------+
//| Sizing: risk amount, absolute caps, lots                          |
//+------------------------------------------------------------------+
double LossPerLot(const string sym, const int dir, const double entry, const double stop)
  {
   double profit = 0.0;
   ENUM_ORDER_TYPE t = (dir > 0) ? ORDER_TYPE_BUY : ORDER_TYPE_SELL;
   if(!OrderCalcProfit(t, sym, 1.0, entry, stop, profit))
      return -1.0;
   return MathAbs(profit);
  }

// per-order volume ceiling: SYMBOL_VOLUME_MAX, InpMaxLotsPerOrder and the room left under SYMBOL_VOLUME_LIMIT
// (aggregate volume of positions and pending orders in one direction on the symbol, 0 = no limit)
double VolumeCap(const string sym, const int dir, string &by)
  {
   double vmax = SymbolInfoDouble(sym, SYMBOL_VOLUME_MAX);
   by = "broker volume max";
   if(InpMaxLotsPerOrder > 0.0 && InpMaxLotsPerOrder < vmax)
     {
      vmax = InpMaxLotsPerOrder;
      by = "InpMaxLotsPerOrder";
     }
   double lim = SymbolInfoDouble(sym, SYMBOL_VOLUME_LIMIT);
   if(lim > 0.0)
     {
      double used = 0.0;
      for(int i = PositionsTotal() - 1; i >= 0; i--)
        {
         ulong tk = PositionGetTicket(i);
         if(tk == 0 || PositionGetString(POSITION_SYMBOL) != sym)
            continue;
         int pd = (PositionGetInteger(POSITION_TYPE) == POSITION_TYPE_BUY) ? 1 : -1;
         if(pd == dir)
            used += PositionGetDouble(POSITION_VOLUME);
        }
      for(int i = OrdersTotal() - 1; i >= 0; i--)
        {
         ulong ot = OrderGetTicket(i);
         if(ot == 0 || OrderGetString(ORDER_SYMBOL) != sym)
            continue;
         ENUM_ORDER_TYPE t = (ENUM_ORDER_TYPE)OrderGetInteger(ORDER_TYPE);
         int od = (t == ORDER_TYPE_BUY || t == ORDER_TYPE_BUY_LIMIT || t == ORDER_TYPE_BUY_STOP ||
                   t == ORDER_TYPE_BUY_STOP_LIMIT) ? 1 : -1;
         if(od == dir)
            used += OrderGetDouble(ORDER_VOLUME_CURRENT);
        }
      double room = lim - used;
      if(room < vmax)
        {
         vmax = MathMax(0.0, room);
         by = "broker volume limit";
        }
     }
   return vmax;
  }

// risk amount after the absolute caps, computed BEFORE CanOpen so that the total-risk cap sees the real size:
// min(equity x risk fraction x symbol mult, InpMaxRiskAmount, InpMaxLotsPerOrder x loss/lot, volume max x loss/lot)
// (shared contract with Python RiskManager.capped_risk)
double CappedRisk(const double riskAmount, const double lossPerLot, const double vcap, const string vcapBy, string &by)
  {
   double r = riskAmount;
   by = "";
   if(InpMaxRiskAmount > 0.0 && InpMaxRiskAmount < r)
     {
      r = InpMaxRiskAmount;
      by = "InpMaxRiskAmount";
     }
   if(lossPerLot > 0.0 && vcap * lossPerLot < r)
     {
      r = vcap * lossPerLot;
      by = vcapBy;
     }
   return r;
  }

double CalcLots(const string sym, const double riskAmount, const double lossPerLot, const double vmax)
  {
   if(lossPerLot <= 0.0 || riskAmount <= 0.0)
      return 0.0;
   double vmin  = SymbolInfoDouble(sym, SYMBOL_VOLUME_MIN);
   double vstep = SymbolInfoDouble(sym, SYMBOL_VOLUME_STEP);
   if(vstep <= 0.0)
      vstep = 0.01;
   double raw = riskAmount / lossPerLot;
   double lots = MathFloor(raw / vstep + 1e-9) * vstep;
   if(lots < vmin)
     {
      if(InpUseMinLot && vmin * lossPerLot <= riskAmount * 1.5)
         lots = vmin;
      else
         return 0.0;
     }
   if(lots > vmax)
      lots = MathFloor(vmax / vstep + 1e-9) * vstep;
   if(lots < vmin || lots <= 0.0)
      return 0.0;   // the volume ceiling is below the broker minimum: no valid order size
   int stepDigits = (int)MathMax(0, MathCeil(-MathLog10(vstep) - 1e-9));
   return NormalizeDouble(lots, stepDigits);
  }

// lot-cap notice: notify at most once per market day per symbol (the OPEN line shows every capped trade)
bool CapNoticeDue(const string sym)
  {
   int n = ArraySize(g_capSym);
   for(int i = 0; i < n; i++)
      if(g_capSym[i] == sym)
        {
         if(g_capDay[i] == g_day)
            return false;
         g_capDay[i] = g_day;
         return true;
        }
   ArrayResize(g_capSym, n + 1);
   ArrayResize(g_capDay, n + 1);
   g_capSym[n] = sym;
   g_capDay[n] = g_day;
   return true;
  }

void ReportCap(const string strat, const string sym, const double rawRisk, const double lossPerLot, const double lots,
               const string by)
  {
   if(by == "" || lossPerLot <= 0.0)
      return;
   string msg = StringFormat("lot cap: intended %.2f lots, sending %.2f (%s %s, limited by %s)",
                             rawRisk / lossPerLot, lots, strat, sym, by);
   if(CapNoticeDue(sym))
      Log(msg, true);
   else
      if(InpVerbose)
         Log(msg);
  }

bool MarginOK(const string sym, const int dir, const double lots, const double price)
  {
   double need = 0.0;
   ENUM_ORDER_TYPE t = (dir > 0) ? ORDER_TYPE_BUY : ORDER_TYPE_SELL;
   if(!OrderCalcMargin(t, sym, lots, price, need))
      return false;
   double freeM = AccountInfoDouble(ACCOUNT_MARGIN_FREE);
   if(need > freeM * 0.8)
     {
      Log(StringFormat("skip %s: insufficient free margin (need %.2f, free %.2f)", sym, need, freeM), true);
      return false;
     }
   return true;
  }

double CommissionPips(const string sym, const double ask)
  {
   if(InpCommissionPerLot <= 0.0)
      return 0.0;
   double pip = SymPip(sym);
   double pv = LossPerLot(sym, 1, ask, ask - pip);
   if(pv <= 0.0)
      return 0.0;
   return InpCommissionPerLot / pv;
  }

//+------------------------------------------------------------------+
//| Order execution: retries, filling fallback, close back-off        |
//+------------------------------------------------------------------+
void AddFilling(ENUM_ORDER_TYPE_FILLING &arr[], const ENUM_ORDER_TYPE_FILLING f)
  {
   int n = ArraySize(arr);
   for(int i = 0; i < n; i++)
      if(arr[i] == f)
         return;
   ArrayResize(arr, n + 1);
   arr[n] = f;
  }

// filling modes to try, in the same order as Python mt5_broker._fillings: allowed FOK / IOC, RETURN, then the rest
int FillingList(const string sym, ENUM_ORDER_TYPE_FILLING &out[])
  {
   ArrayResize(out, 0);
   long fm = SymbolInfoInteger(sym, SYMBOL_FILLING_MODE);
   if((fm & SYMBOL_FILLING_FOK) != 0)
      AddFilling(out, ORDER_FILLING_FOK);
   if((fm & SYMBOL_FILLING_IOC) != 0)
      AddFilling(out, ORDER_FILLING_IOC);
   AddFilling(out, ORDER_FILLING_RETURN);
   AddFilling(out, ORDER_FILLING_FOK);
   AddFilling(out, ORDER_FILLING_IOC);
   return ArraySize(out);
  }

bool IsDone(const bool sent, const uint rc)
  {
   return sent && (rc == TRADE_RETCODE_DONE || rc == TRADE_RETCODE_PLACED || rc == TRADE_RETCODE_DONE_PARTIAL);
  }

bool IsPriceRetcode(const uint rc)
  {
   return (rc == TRADE_RETCODE_REQUOTE || rc == TRADE_RETCODE_PRICE_CHANGED || rc == TRADE_RETCODE_PRICE_OFF ||
           rc == TRADE_RETCODE_TOO_MANY_REQUESTS);
  }

// the request may have reached the server: never re-send before checking for the position
bool IsNoReply(const bool sent, const uint rc)
  {
   return (rc == TRADE_RETCODE_TIMEOUT || rc == TRADE_RETCODE_CONNECTION || (!sent && rc == 0));
  }

bool WaitOwnTrade(const string sym, const long magic)
  {
   for(int k = 0; k < 3; k++)
     {
      Sleep(1000);
      if(OwnTradeOnSymbol(sym, magic))
         return true;
     }
   return false;
  }

// market entry with SL/TP absolute (as in Python): up to 3 sends on requote / price changed / off quotes with
// fresh prices (price 0.0 -> CTrade reads the current bid/ask), filling-mode fallback on INVALID_FILL, and
// after a timeout / no reply a check for the new position before any re-send
bool SendEntry(const int dir, const double lots, const string sym, const double sl, const double tp,
               const long magic, const string cmt, string &err)
  {
   err = "";
   g_trade.SetExpertMagicNumber((ulong)magic);
   ENUM_ORDER_TYPE_FILLING fills[];
   int nf = FillingList(sym, fills);
   int fstep = 0;
   int priceFails = 0;
   int noReply = 0;
   for(int guard = 0; guard < 12; guard++)
     {
      g_trade.SetTypeFilling(fills[fstep]);
      bool sent = (dir > 0) ? g_trade.Buy(lots, sym, 0.0, sl, tp, cmt) : g_trade.Sell(lots, sym, 0.0, sl, tp, cmt);
      uint rc = g_trade.ResultRetcode();
      if(IsDone(sent, rc))
         return true;
      err = StringFormat("%u %s", rc, g_trade.ResultRetcodeDescription());
      if(rc == TRADE_RETCODE_INVALID_FILL && fstep + 1 < nf)
        {
         fstep++;
         continue;
        }
      if(IsNoReply(sent, rc))
        {
         if(WaitOwnTrade(sym, magic))
           {
            Log(StringFormat("%s %s: no reply to the order (%s) but the position exists - not re-sent", cmt, sym, err));
            return true;
           }
         noReply++;
         if(noReply >= 3)
            return false;
         continue;
        }
      if(IsPriceRetcode(rc))
        {
         priceFails++;
         if(priceFails >= 3)
            return false;
         Sleep(300);
         continue;
        }
      return false;
     }
   return false;
  }

int FailIdx(const ulong tk)
  {
   for(int i = 0; i < ArraySize(g_failTk); i++)
      if(g_failTk[i] == tk)
         return i;
   return -1;
  }

void DropFail(const int i)
  {
   ArrayRemove(g_failTk, i, 1);
   ArrayRemove(g_failNext, i, 1);
   ArrayRemove(g_failNote, i, 1);
  }

// once per cycle: forget back-off entries and no-SL notices of positions that no longer exist
void PruneFails()
  {
   for(int i = ArraySize(g_failTk) - 1; i >= 0; i--)
      if(!PositionSelectByTicket(g_failTk[i]))
         DropFail(i);
   for(int i = ArraySize(g_noSLTk) - 1; i >= 0; i--)
      if(!PositionSelectByTicket(g_noSLTk[i]))
        {
         ArrayRemove(g_noSLTk, i, 1);
         ArrayRemove(g_noSLNote, i, 1);
        }
  }

// returns true when the position is gone. A failed close is retried with a back-off per ticket (20 s, or 300 s
// while the market is closed / trading is disabled) and pushed at most once per hour per ticket.
bool ClosePos(const ulong ticket, const string reason)
  {
   if(!PositionSelectByTicket(ticket))
      return true;
   int fi = FailIdx(ticket);
   if(fi >= 0 && Secs(TimeLocal(), g_failNext[fi]) < 0)
      return false;
   string sym = PositionGetString(POSITION_SYMBOL);
   ENUM_ORDER_TYPE_FILLING fills[];
   int nf = FillingList(sym, fills);
   int fstep = 0;
   int priceFails = 0;
   int noReply = 0;
   uint rc = 0;
   bool done = false;
   for(int guard = 0; guard < 12; guard++)
     {
      g_trade.SetTypeFilling(fills[fstep]);
      bool sent = g_trade.PositionClose(ticket, (ulong)InpDeviationPoints);
      rc = g_trade.ResultRetcode();
      if(IsDone(sent, rc) || rc == TRADE_RETCODE_POSITION_CLOSED || !PositionSelectByTicket(ticket))
        {
         done = true;
         break;
        }
      if(rc == TRADE_RETCODE_INVALID_FILL && fstep + 1 < nf)
        {
         fstep++;
         continue;
        }
      if(IsNoReply(sent, rc))
        {
         noReply++;
         if(noReply >= 3)
            break;
         Sleep(1000);
         if(!PositionSelectByTicket(ticket))
           {
            done = true;
            break;
           }
         continue;
        }
      if(IsPriceRetcode(rc))
        {
         priceFails++;
         if(priceFails >= 3)
            break;
         Sleep(300);
         continue;
        }
      break;
     }
   if(done)
     {
      if(fi >= 0)
         DropFail(fi);
      Log(StringFormat("CLOSE %s #%s (%s)", sym, IntegerToString((long)ticket), reason), true);
      return true;
     }
   if(fi < 0)
     {
      fi = ArraySize(g_failTk);
      ArrayResize(g_failTk, fi + 1);
      ArrayResize(g_failNext, fi + 1);
      ArrayResize(g_failNote, fi + 1);
      g_failTk[fi] = ticket;
      g_failNote[fi] = 0;
     }
   bool slow = (rc == TRADE_RETCODE_MARKET_CLOSED || rc == TRADE_RETCODE_TRADE_DISABLED ||
                rc == TRADE_RETCODE_CLIENT_DISABLES_AT || rc == TRADE_RETCODE_SERVER_DISABLES_AT);
   int wait = slow ? 300 : 20;
   datetime now = TimeLocal();
   g_failNext[fi] = now + wait;
   bool notify = (g_failNote[fi] == 0 || Secs(now, g_failNote[fi]) >= 3600 || Secs(now, g_failNote[fi]) < 0);
   if(notify)
      g_failNote[fi] = now;
   Log(StringFormat("CLOSE FAILED %s #%s (%s): %u %s - next try in %d s", sym, IntegerToString((long)ticket), reason,
                    rc, g_trade.ResultRetcodeDescription(), wait), notify);
   return false;
  }

//+------------------------------------------------------------------+
//| Indicators (computed from closed bars, identical to Python)       |
//+------------------------------------------------------------------+
// the newest CLOSED bars of sym, newest first (r[0] = last closed bar; r is not a series array). Live: a bar is
// closed by TIME (shared rule with the Python engine): once the server time (newest quote of any symbol) has
// reached its open + its length + GT_BAR_SETTLE_SEC, whether or not this symbol has ticked in the next bar yet (MT5
// forms a bar only at its first tick), so every pair's just-closed bar is decided in the same cycle, in
// alphabetical order. Strategy Tester: the bar before the newest one, as before (tester results unchanged).
// Returns the number of bars in r[].
int ClosedRates(const string sym, const ENUM_TIMEFRAMES tf, const int count, const datetime nowSrv, MqlRates &r[])
  {
   ArrayResize(r, 0);
   MqlRates a[];
   ArraySetAsSeries(a, true);
   int got = g_tester ? CopyRates(sym, tf, 1, count, a) : CopyRates(sym, tf, 0, count + 2, a);
   if(got <= 0)
      return 0;
   int skip = 0;
   if(!g_tester)
     {
      long len = (long)PeriodSeconds(tf);
      while(skip < got && (long)a[skip].time + len + GT_BAR_SETTLE_SEC > (long)nowSrv)
         skip++;
     }
   int n = got - skip;
   if(n > count)
      n = count;
   ArrayResize(r, n);
   for(int k = 0; k < n; k++)
      r[k] = a[skip + k];
   return n;
  }

bool NRIndicators(const string sym, const datetime nowSrv, MqlRates &last, double &mid, double &upper, double &lower,
                  double &atrv)
  {
   MqlRates r[];
   int need = (int)MathMax(InpBBPeriod, InpATRPeriod + 1) + 2;
   int got = ClosedRates(sym, PERIOD_M15, need, nowSrv, r);   // r[0] = last closed bar
   if(got < need)
      return false;
   last = r[0];
   double sum = 0.0;
   for(int i = 0; i < InpBBPeriod; i++)
      sum += r[i].close;
   mid = sum / InpBBPeriod;
   double var = 0.0;
   for(int i = 0; i < InpBBPeriod; i++)
      var += (r[i].close - mid) * (r[i].close - mid);
   double sd = MathSqrt(var / InpBBPeriod);            // population std (iBands)
   upper = mid + InpBBDev * sd;
   lower = mid - InpBBDev * sd;
   double s2 = 0.0;
   for(int i = 0; i < InpATRPeriod; i++)
     {
      double pc = r[i + 1].close;
      double tr = MathMax(r[i].high - r[i].low, MathMax(MathAbs(r[i].high - pc), MathAbs(r[i].low - pc)));
      s2 += tr;
     }
   atrv = s2 / InpATRPeriod;                            // SMA of true range (iATR)
   return true;
  }

double ATRH1(const string sym, const int period, const datetime nowSrv)
  {
   MqlRates r[];
   int need = period + 1;
   int got = ClosedRates(sym, PERIOD_H1, need, nowSrv, r);   // r[0] = last closed H1 bar
   if(got < need)
      return -1.0;
   double s = 0.0;
   for(int i = 0; i < period; i++)
     {
      double pc = r[i + 1].close;
      s += MathMax(r[i].high - r[i].low, MathMax(MathAbs(r[i].high - pc), MathAbs(r[i].low - pc)));
     }
   return s / period;
  }

//+------------------------------------------------------------------+
//| Night Reversion                                                   |
//+------------------------------------------------------------------+
bool InNRWindow(const datetime barMarket)
  {
   MqlDateTime s;
   TimeToStruct(barMarket, s);
   int dow = s.day_of_week;   // 0 Sunday ... 6 Saturday
   int hr = s.hour;
   if(dow == 0 || dow == 6)
      return false;
   if(InpSkipMonday && dow == 1 && hr < 2)
      return false;
   if(dow == 5 && hr >= 20)
      return false;
   return (hr == InpEntryHour1 || hr == InpEntryHour2);
  }

double FavorableTP(const int dir, const double openPrice, const double mid)
  {
   if(dir > 0 && mid > openPrice)
      return mid;
   if(dir < 0 && mid < openPrice)
      return mid;
   return 0.0;
  }

void NRTimeStops(const datetime nowSrv)
  {
   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      ulong tk = PositionGetTicket(i);
      if(tk == 0)
         continue;
      if(PositionGetInteger(POSITION_MAGIC) != InpNRMagic)
         continue;
      datetime ot = (datetime)PositionGetInteger(POSITION_TIME);
      if(nowSrv >= Floor15(ot) + InpMaxHoldBars * 900)
         ClosePos(tk, "time stop");
     }
  }

void NRManage(const string sym, const double mid, const datetime nowSrv)
  {
   MqlTick tick;
   if(!SymbolInfoTick(sym, tick))
      return;
   int digits = (int)SymbolInfoInteger(sym, SYMBOL_DIGITS);
   double point = SymbolInfoDouble(sym, SYMBOL_POINT);
   long stops = SymbolInfoInteger(sym, SYMBOL_TRADE_STOPS_LEVEL);
   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      ulong tk = PositionGetTicket(i);
      if(tk == 0)
         continue;
      if(PositionGetInteger(POSITION_MAGIC) != InpNRMagic || PositionGetString(POSITION_SYMBOL) != sym)
         continue;
      datetime ot = (datetime)PositionGetInteger(POSITION_TIME);
      if(nowSrv >= Floor15(ot) + InpMaxHoldBars * 900)
        {
         ClosePos(tk, "time stop");
         continue;
        }
      int dir = (PositionGetInteger(POSITION_TYPE) == POSITION_TYPE_BUY) ? 1 : -1;
      double op = PositionGetDouble(POSITION_PRICE_OPEN);
      double sl = PositionGetDouble(POSITION_SL);
      double curTP = PositionGetDouble(POSITION_TP);
      double tp = FavorableTP(dir, op, mid);
      if(tp > 0.0)
        {
         tp = NormalizeDouble(tp, digits);
         double px = (dir > 0) ? tick.bid : tick.ask;
         if((dir > 0 && px >= tp) || (dir < 0 && px <= tp) || MathAbs(tp - px) < (stops + 2) * point)
           {
            ClosePos(tk, "price at moving average");
            continue;
           }
        }
      if(MathAbs(tp - curTP) > point * 0.5)
        {
         if(g_trade.PositionModify(tk, sl, tp))
           {
            if(InpVerbose)
               Log(StringFormat("MODIFY %s TP -> %s", sym, DoubleToString(tp, digits)));
           }
         else
           {
            uint rc = g_trade.ResultRetcode();
            // close only when the price is already beyond the TP (fresh quote); on any other failure (no connection,
            // too many requests, ...) the position keeps its SL and the time stop, and the TP is retried next bar
            bool beyond = false;
            MqlTick t2;
            if(tp > 0.0 && SymbolInfoTick(sym, t2))
              {
               double px2 = (dir > 0) ? t2.bid : t2.ask;
               beyond = ((dir > 0 && px2 >= tp) || (dir < 0 && px2 <= tp));
              }
            if(beyond)
               ClosePos(tk, "price beyond TP (TP not placeable)");
            else
               Log(StringFormat("modify failed %s: %u %s (SL kept, TP retried next bar)", sym, rc,
                                g_trade.ResultRetcodeDescription()));
           }
        }
     }
  }

// NR entry signal of a closed bar with the CURRENT quote: entry window, spread, cost and news filters, band signal,
// TP on the profitable side outside the stops level. Returns false when there is no signal.
bool NRSignal(const string sym, const MqlRates &bar, const double mid, const double upper, const double lower,
              const double atrv, int &dir, double &entry, double &sl, double &tp, double &cost)
  {
   dir = 0;
   datetime barMkt = ServerToMarket(bar.time);
   if(!InNRWindow(barMkt))
      return false;
   MqlTick tick;
   if(!SymbolInfoTick(sym, tick) || tick.bid <= 0.0 || tick.ask <= 0.0)
      return false;
   double pip = SymPip(sym);
   double spread = (tick.ask - tick.bid) / pip;
   if(spread > InpNRMaxSpreadPips)
      return false;
   cost = spread + CommissionPips(sym, tick.ask) + InpNRSlippagePips;
   if(atrv / pip < InpATRCostMult * cost)
      return false;
   double sd = (InpBBDev > 0.0) ? (upper - mid) / InpBBDev : 0.0;
   if(InpMaxBandZ > 0.0 && sd > 0.0 && MathAbs(bar.close - mid) > InpMaxBandZ * sd)
      return false;
   if(InpMaxBarRangeATR > 0.0 && (bar.high - bar.low) > InpMaxBarRangeATR * atrv)
      return false;
   if(bar.close > upper)
      dir = -1;
   else
      if(bar.close < lower)
         dir = 1;
   if(dir == 0)
      return false;
   int digits = (int)SymbolInfoInteger(sym, SYMBOL_DIGITS);
   double point = SymbolInfoDouble(sym, SYMBOL_POINT);
   long stops = SymbolInfoInteger(sym, SYMBOL_TRADE_STOPS_LEVEL);
   entry = (dir > 0) ? tick.ask : tick.bid;
   sl = NormalizeDouble(entry - dir * InpSLATRMult * atrv, digits);
   tp = FavorableTP(dir, entry, mid);
   if(tp <= 0.0)
      return false;
   tp = NormalizeDouble(tp, digits);
   if(MathAbs(tp - entry) < (stops + 2) * point)
      return false;
   return true;
  }

// NR entry of symbol g_sym[i] on a closed bar. A signal that an entry gate blocks (broker clock waiting / mismatch,
// first-run deal history, cash flow pending, deal history unreadable) is deferred, not dropped (shared rule with
// the Python engine): retried on the next cycles while its bar is fresh (RetryDeferred), with the current quote
// and every guard checked again.
void NREntry(const int i, const MqlRates &bar, const double mid, const double upper, const double lower,
             const double atrv, const double eq, const bool deferred)
  {
   string sym = g_sym[i];
   int dir = 0;
   double entry = 0.0, sl = 0.0, tp = 0.0, cost = 0.0;
   if(!NRSignal(sym, bar, mid, upper, lower, atrv, dir, entry, sl, tp, cost))
     {
      if(deferred)
         Log(StringFormat("NR %s deferred signal of the %s bar: no signal any more at the current quote, dropped", sym,
                          TimeToString(bar.time, TIME_DATE | TIME_MINUTES)));
      return;
     }
   string gate;
   if(!EntryGateOpen(gate))
     {
      if(!g_defOn[i] || g_defBar[i].time != bar.time)
         Log(StringFormat("NR %s signal of the %s bar deferred: %s (retried until %s)", sym,
                          TimeToString(bar.time, TIME_DATE | TIME_MINUTES), gate,
                          TimeToString((datetime)((long)bar.time + 900 + GT_FRESH_SEC), TIME_DATE | TIME_SECONDS)));
      g_defOn[i] = true;
      g_defBar[i] = bar;
      g_defMid[i] = mid;
      g_defUp[i] = upper;
      g_defLo[i] = lower;
      g_defAtr[i] = atrv;
      return;
     }
   int digits = (int)SymbolInfoInteger(sym, SYMBOL_DIGITS);
   double pip = SymPip(sym);
   double rf = RiskFraction(true, eq) * SymbolMult(sym);
   double rawRisk = eq * rf;
   double lossLot = LossPerLot(sym, dir, entry, sl);
   string capBy = "";
   double vcap = VolumeCap(sym, dir, capBy);
   string by = "";
   double risk = CappedRisk(rawRisk, lossLot, vcap, capBy, by);
   string why;
   if(!CanOpen(sym, eq, dir, risk, why))
     {
      if(InpVerbose)
         Log(StringFormat("NR %s signal skipped: %s", sym, why));
      return;
     }
   double lots = CalcLots(sym, risk, lossLot, vcap);
   if(lots <= 0.0)
     {
      if(InpVerbose)
         Log(StringFormat("NR %s skipped: lot below minimum (risk %.2f)", sym, risk));
      return;
     }
   if(!MarginOK(sym, dir, lots, entry))
      return;
   ReportCap("NR", sym, rawRisk, lossLot, lots, by);
   string err = "";
   bool ok = SendEntry(dir, lots, sym, sl, tp, InpNRMagic, "GT_NR", err);
   string capTxt = "";
   if(by != "")
      capTxt = StringFormat(" [capped from %.2f%%]", rf * 100.0);
   string desc = StringFormat("NR %s %s lots=%.2f SL=%s TP=%s risk=%.2f%%%s ATR=%.1fp cost=%.1fp",
                              (dir > 0 ? "BUY" : "SELL"), sym, lots, DoubleToString(sl, digits),
                              DoubleToString(tp, digits), (eq > 0.0 ? risk / eq : rf) * 100.0, capTxt, atrv / pip, cost);
   if(ok)
      Log("OPEN " + desc, true);
   else
      Log("ORDER FAILED " + desc + ": " + err, true);
  }

// NR signals deferred by an entry gate: retried in symbol (alphabetical) order before the new bars of the cycle,
// while their bar is fresh (GT_FRESH_SEC after its close); then dropped (logged)
void RetryDeferred(const datetime nowSrv, const double eq)
  {
   for(int i = 0; i < g_nsym; i++)
     {
      if(!g_defOn[i])
         continue;
      string gate;
      bool open = EntryGateOpen(gate);
      if(nowSrv - (g_defBar[i].time + 900) > GT_FRESH_SEC)
        {
         g_defOn[i] = false;
         Log(StringFormat("NR %s signal of the %s bar dropped: not taken within %d s of the bar close (%s)", g_sym[i],
                          TimeToString(g_defBar[i].time, TIME_DATE | TIME_MINUTES), GT_FRESH_SEC,
                          open ? "entry gate open, no new check" : gate));
         continue;
        }
      if(!open)
         continue;   // still blocked: tried again on the next cycle
      g_defOn[i] = false;
      Log(StringFormat("NR %s deferred signal of the %s bar: entry gate open again, checking it now", g_sym[i],
                       TimeToString(g_defBar[i].time, TIME_DATE | TIME_MINUTES)));
      NREntry(i, g_defBar[i], g_defMid[i], g_defUp[i], g_defLo[i], g_defAtr[i], eq, true);
     }
  }

void ProcessNR(const datetime nowSrv, const double eq)
  {
   NRTimeStops(nowSrv);
   RetryDeferred(nowSrv, eq);
   // the last closed M15 bar: live by TIME (open + 15 min + GT_BAR_SETTLE_SEC <= server time, see ClosedRates), the
   // same bar for every pair; Strategy Tester by position (the bar before the newest one), as before
   datetime lastClosed = Floor15((datetime)((long)nowSrv - GT_BAR_SETTLE_SEC)) - 900;
   for(int i = 0; i < g_nsym; i++)
     {
      string sym = g_sym[i];
      datetime t1 = g_tester ? iTime(sym, PERIOD_M15, 1) : lastClosed;   // open time of the last closed bar
      if(t1 <= 0 || t1 == g_lastBar[i])
         continue;
      MqlRates bar;
      double mid, upper, lower, atrv;
      if(!NRIndicators(sym, nowSrv, bar, mid, upper, lower, atrv))
         continue;
      if(bar.time <= g_lastBar[i])
         continue;   // live: this pair has no bar in the just-closed slot (no tick in it): nothing new
      g_lastBar[i] = bar.time;
      NRManage(sym, mid, nowSrv);
      // entries only on a fresh bar close (avoid acting on stale bars after restarts / data gaps);
      // the same 150 s window as Python (engine.py FRESH_SIGNAL), also for the first bar after a start
      if(nowSrv - (bar.time + 900) > GT_FRESH_SEC)
         continue;
      NREntry(i, bar, mid, upper, lower, atrv, eq, false);
     }
  }

//+------------------------------------------------------------------+
//| Euro Session                                                      |
//+------------------------------------------------------------------+
void ProcessES(const datetime nowSrv, const double eq)
  {
   datetime utc = ServerToUTC(nowSrv);
   // manage: close at exit hour UTC
   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      ulong tk = PositionGetTicket(i);
      if(tk == 0)
         continue;
      if(PositionGetInteger(POSITION_MAGIC) != InpESMagic)
         continue;
      datetime openUtc = ServerToUTC((datetime)PositionGetInteger(POSITION_TIME));
      MqlDateTime os;
      TimeToStruct(openUtc, os);
      datetime exitUtc = DayStart(openUtc) + InpESExitUTC * 3600;
      if(os.hour >= InpESExitUTC)
         exitUtc += 86400;
      if(utc >= exitUtc)
         ClosePos(tk, "session exit");
     }
   // entry
   MqlDateTime u;
   TimeToStruct(utc, u);
   datetime uday = DayStart(utc);
   if(g_lastESDay == uday)
      return;
   if(u.day_of_week < 1 || u.day_of_week > 5 || u.hour != InpESEntryUTC || u.min >= 15)
      return;
   string gate;
   if(!EntryGateOpen(gate))
      return;   // decide only on a verified broker clock and settled cash flows (the day stays open meanwhile)
   if(HasESPosition())
      return;
   if(!g_tester && ((long)nowSrv % 3600) < GT_BAR_SETTLE_SEC)
      return;   // live: the H1 bar that just ended counts as closed GT_BAR_SETTLE_SEC after its end (ClosedRates)
   MqlTick tick;
   if(!SymbolInfoTick(g_esSym, tick) || tick.bid <= 0.0)
      return;
   g_lastESDay = uday;   // one decision per day
   double pip = SymPip(g_esSym);
   double spread = (tick.ask - tick.bid) / pip;
   double a = ATRH1(g_esSym, InpESATRPeriodH1, nowSrv);
   if(a <= 0.0 || spread > InpESMaxSpreadPips)
     {
      Log(StringFormat("ES: no entry today (spread %.1fp, ATR %.1fp)", spread, a / pip));
      return;
     }
   int dir = (InpESDirection >= 0) ? 1 : -1;
   int digits = (int)SymbolInfoInteger(g_esSym, SYMBOL_DIGITS);
   double entry = (dir > 0) ? tick.ask : tick.bid;
   double sl = NormalizeDouble(entry - dir * InpESSLATRMult * a, digits);
   double rf = RiskFraction(false, eq) * SymbolMult(g_esSym);
   double rawRisk = eq * rf;
   double lossLot = LossPerLot(g_esSym, dir, entry, sl);
   string capBy = "";
   double vcap = VolumeCap(g_esSym, dir, capBy);
   string by = "";
   double risk = CappedRisk(rawRisk, lossLot, vcap, capBy, by);
   string why;
   if(!CanOpen(g_esSym, eq, dir, risk, why))
     {
      Log("ES signal skipped: " + why);
      return;
     }
   double lots = CalcLots(g_esSym, risk, lossLot, vcap);
   if(lots <= 0.0)
     {
      Log("ES skipped: lot below minimum");
      return;
     }
   if(!MarginOK(g_esSym, dir, lots, entry))
      return;
   ReportCap("ES", g_esSym, rawRisk, lossLot, lots, by);
   string err = "";
   bool ok = SendEntry(dir, lots, g_esSym, sl, 0.0, InpESMagic, "GT_ES", err);
   string capTxt = "";
   if(by != "")
      capTxt = StringFormat(" [capped from %.2f%%]", rf * 100.0);
   string desc = StringFormat("ES %s %s lots=%.2f SL=%s risk=%.2f%%%s ATR(H1)=%.1fp", (dir > 0 ? "BUY" : "SELL"),
                              g_esSym, lots, DoubleToString(sl, digits), (eq > 0.0 ? risk / eq : rf) * 100.0, capTxt,
                              a / pip);
   if(ok)
      Log("OPEN " + desc, true);
   else
      Log("ORDER FAILED " + desc + ": " + err, true);
  }

//+------------------------------------------------------------------+
//| Cash flows: deposits / withdrawals / credit / bonus are not P/L   |
//+------------------------------------------------------------------+
bool IsCashFlow(const long dealType)
  {
   return (dealType == DEAL_TYPE_BALANCE || dealType == DEAL_TYPE_CREDIT || dealType == DEAL_TYPE_BONUS);
  }

// first run (no persisted cursor): every deal already in the history counts as seen and is NOT applied - but
// only once the history looks complete: the deals sum to the balance (credit deals to the credit) within
// max(1, 0.1%), or the set of cash-flow deals stayed the same for GT_PRIME_STABLE_SEC (an empty set while balance
// or credit is not zero never counts). After GT_PRIME_MAX_SEC the cursor is primed anyway. Priming without matching
// sums is notified (warning). Until then new entries wait; closes, stops and the guards keep working. The read
// becomes the reconciliation reference (balance + credit, newest deal). Returns true when the cursor is primed.
// Live only (shared contract with the Python engine).
bool TryPrimeFlowCursor()
  {
   if(g_flowPrimed)
      return true;
   datetime now = TimeLocal();
   if(g_primeStart == 0 || Secs(now, g_primeStart) < 0)
      g_primeStart = now;
   if(g_primeTry != 0 && Secs(now, g_primeTry) < 5 && Secs(now, g_primeTry) >= 0)
      return false;
   g_primeTry = now;
   bool late = (Secs(now, g_primeStart) >= GT_PRIME_MAX_SEC);
   double bc0 = AccountInfoDouble(ACCOUNT_BALANCE) + AccountInfoDouble(ACCOUNT_CREDIT);
   if(!HistorySelect(0, GT_FAR_FUTURE))
     {
      if(late && (g_primeNote == 0 || Secs(now, g_primeNote) >= GT_REPEAT_SEC || Secs(now, g_primeNote) < 0))
        {
         g_primeNote = now;
         Log("the deal history cannot be read: cash-flow tracking not started, new entries wait", true);
        }
      return false;
     }
   int n = HistoryDealsTotal();
   ulong mx = 0;
   datetime mxTime = 0;
   double sumBal = 0.0;
   double sumCred = 0.0;
   int nCash = 0;
   ulong cashSum = 0;
   ulong cashXor = 0;
   for(int i = 0; i < n; i++)
     {
      ulong tk = HistoryDealGetTicket(i);
      if(tk == 0)
         continue;
      if(tk > mx)
        {
         mx = tk;
         mxTime = (datetime)HistoryDealGetInteger(tk, DEAL_TIME);
        }
      long type = HistoryDealGetInteger(tk, DEAL_TYPE);
      double amt = HistoryDealGetDouble(tk, DEAL_PROFIT) + HistoryDealGetDouble(tk, DEAL_COMMISSION) +
                   HistoryDealGetDouble(tk, DEAL_SWAP) + HistoryDealGetDouble(tk, DEAL_FEE);
      if(type == DEAL_TYPE_CREDIT)
         sumCred += amt;
      else
         sumBal += amt;
      if(IsCashFlow(type))
        {
         nCash++;
         cashSum += tk;
         cashXor ^= tk;
        }
     }
   double bal = AccountInfoDouble(ACCOUNT_BALANCE);
   double cred = AccountInfoDouble(ACCOUNT_CREDIT);
   if(MathAbs(bal + cred - bc0) >= 0.005)
      return false;   // a deal was booked during the read: tried again (the read and the balance must agree)
   bool sums = (MathAbs(sumBal - bal) <= MathMax(1.0, 0.001 * MathAbs(bal)) &&
                MathAbs(sumCred - cred) <= MathMax(1.0, 0.001 * MathAbs(cred)));
   bool same = (g_primeRefAt != 0 && nCash == g_primeRefN && cashSum == g_primeRefSum && cashXor == g_primeRefXor);
   if(!same || Secs(now, g_primeRefAt) < 0)
     {
      same = false;
      g_primeRefAt = now;
      g_primeRefN = nCash;
      g_primeRefSum = cashSum;
      g_primeRefXor = cashXor;
     }
   // an EMPTY set of cash deals while balance or credit is non-zero is never a complete history (no 'stable')
   bool emptyCash = (nCash == 0 && (MathAbs(bal) >= 0.005 || MathAbs(cred) >= 0.005));
   bool stable = (same && !emptyCash && Secs(now, g_primeRefAt) >= GT_PRIME_STABLE_SEC);
   if(!sums && !stable && !late)
      return false;
   g_flowTicket = mx;
   g_flowScan = TimeCurrent();
   g_flowPrimed = true;
   // the reconciliation reference: this read (balance + credit read after it, newest deal of any type)
   g_moneyRef = bal + cred;
   g_dealRef = mx;
   g_dealRefTime = (mx > 0 && mxTime > 0) ? mxTime : TimeCurrent();
   g_refKnown = true;
   g_pendingSince = 0;
   g_stateDirty = true;
   string how = "NOT confirmed";
   if(sums)
      how = "deals match balance and credit";
   else
      if(stable)
         how = StringFormat("cash-flow deals unchanged for %d s", GT_PRIME_STABLE_SEC);
   Log(StringFormat("cash-flow tracking started: %d existing deals marked as seen (cursor #%s, %s)", n,
                    IntegerToString((long)mx), how));
   if(!sums)
      Log(StringFormat("WARNING: the deal history was not confirmed complete (%s; deals sum to %.2f, balance %.2f; "
                       "credit deals %.2f, credit %.2f). Existing deals are marked as seen anyway: a deposit or "
                       "withdrawal that reaches the history later is checked against the balance like any new deal.",
                       stable ? StringFormat("cash-flow deals unchanged for %d s", GT_PRIME_STABLE_SEC) :
                       StringFormat("not within %d min", GT_PRIME_MAX_SEC / 60), sumBal, bal, sumCred, cred), true);
   return true;
  }

// effect of a deal on balance + credit (a CREDIT deal moves the credit)
double DealEffect(const ulong tk)
  {
   return HistoryDealGetDouble(tk, DEAL_PROFIT) + HistoryDealGetDouble(tk, DEAL_COMMISSION) +
          HistoryDealGetDouble(tk, DEAL_SWAP) + HistoryDealGetDouble(tk, DEAL_FEE);
  }

// the deals (any type) newer than the reconciliation reference deal, oldest first (time, then ticket). The window
// starts 1 day before the reference deal's time (at least the last 2 days); without a reference (state of an
// earlier 1.2 build) 2 days before the last read. Returns false when the deal history cannot be read.
bool ReadNewDeals(ulong &tk[], long &type[], double &eff[], datetime &tm[])
  {
   ArrayResize(tk, 0);
   ArrayResize(type, 0);
   ArrayResize(eff, 0);
   ArrayResize(tm, 0);
   long fromL = (long)TimeCurrent() - 2 * 86400;
   if(g_refKnown)
     {
      if((long)g_dealRefTime - 86400 < fromL)
         fromL = (long)g_dealRefTime - 86400;
     }
   else
      if(g_flowScan > 0 && (long)g_flowScan - 2 * 86400 < fromL)
         fromL = (long)g_flowScan - 2 * 86400;
   if(fromL < 0)
      fromL = 0;
   if(!HistorySelect((datetime)fromL, GT_FAR_FUTURE))
      return false;
   int n = HistoryDealsTotal();
   int m = 0;
   for(int i = 0; i < n; i++)
     {
      ulong t = HistoryDealGetTicket(i);
      if(t == 0 || (g_refKnown && t <= g_dealRef))
         continue;
      datetime dt = (datetime)HistoryDealGetInteger(t, DEAL_TIME);
      ArrayResize(tk, m + 1);
      ArrayResize(type, m + 1);
      ArrayResize(eff, m + 1);
      ArrayResize(tm, m + 1);
      int j = m;
      while(j > 0 && (tm[j - 1] > dt || (tm[j - 1] == dt && tk[j - 1] > t)))
        {
         tk[j] = tk[j - 1];
         type[j] = type[j - 1];
         eff[j] = eff[j - 1];
         tm[j] = tm[j - 1];
         j--;
        }
      tk[j] = t;
      type[j] = HistoryDealGetInteger(t, DEAL_TYPE);
      eff[j] = DealEffect(t);
      tm[j] = dt;
      m++;
     }
   return true;
  }

// absorbed records (changes counted as profit / loss at the pending limit) are kept GT_ABSORB_KEEP_SEC
void PruneAbsorbed()
  {
   long nowL = (long)TimeCurrent();
   for(int i = ArraySize(g_absAmt) - 1; i >= 0; i--)
      if(nowL - (long)g_absTime[i] > GT_ABSORB_KEEP_SEC)
        {
         ArrayRemove(g_absAmt, i, 1);
         ArrayRemove(g_absTime, i, 1);
         g_stateDirty = true;
        }
  }

void AddAbsorbed(const double amt)
  {
   PruneAbsorbed();
   if(ArraySize(g_absAmt) >= GT_ABSORB_MAX)
     {
      ArrayRemove(g_absAmt, 0, 1);
      ArrayRemove(g_absTime, 0, 1);
     }
   int n = ArraySize(g_absAmt);
   ArrayResize(g_absAmt, n + 1);
   ArrayResize(g_absTime, n + 1);
   g_absAmt[n] = amt;
   datetime srvNow = TimeTradeServer();   // server time now; TimeCurrent() is the last tick (stale over a weekend)
   g_absTime[n] = (srvNow > TimeCurrent()) ? srvNow : TimeCurrent();
   g_stateDirty = true;
  }

// deals booked (server time) before the newest change counted as profit / loss (strict), or also in its second
// (!strict), are LATE deals: that change was taken into the reference balance + credit, so they are already counted
// there (Python _late_deals). Sets late[] = 1 for them and returns the sum of their effects (count in nl).
double MarkLateDeals(const datetime &tm[], const double &eff[], const bool strict, int &late[], int &nl)
  {
   nl = 0;
   double sx = 0.0;
   int na = ArraySize(g_absTime);
   datetime wm = 0;
   for(int r = 0; r < na; r++)
      if(g_absTime[r] > wm)
         wm = g_absTime[r];
   for(int i = 0; i < ArraySize(tm); i++)
     {
      late[i] = 0;
      if(na == 0 || !(tm[i] < wm || (!strict && tm[i] == wm)))
         continue;
      late[i] = 1;
      sx += eff[i];
      nl++;
     }
   return sx;
  }

// late deals of a change already counted as profit / loss: with them left out, do the new deals explain the change?
// Tries the strict watermark first, then its second (deal times have whole seconds). late[] = 1 for the late deals
// of the chosen reading (strict when neither explains it: used at the pending limit).
bool MatchLateDeals(const datetime &tm[], const double &eff[], const double delta, const double sum,
                    const double tol, int &late[])
  {
   int nl = 0;
   double sx = MarkLateDeals(tm, eff, false, late, nl);
   bool wideOk = (nl > 0 && MathAbs(delta - (sum - sx)) <= tol);
   sx = MarkLateDeals(tm, eff, true, late, nl);
   if(nl > 0 && MathAbs(delta - (sum - sx)) <= tol)
      return true;
   if(wideOk)
     {
      MarkLateDeals(tm, eff, false, late, nl);
      return true;
     }
   return false;
  }

// notifies the late cash deals (newer than the cash cursor) that are left out: not applied again
void NoteLateDeals(const ulong &tk[], const long &type[], const double &eff[], const datetime &tm[],
                   const int &late[])
  {
   for(int i = 0; i < ArraySize(tk); i++)
      if(late[i] != 0 && IsCashFlow(type[i]) && tk[i] > g_flowTicket)
         Log(StringFormat("late cash deal #%s %+.2f booked %s (server time): already counted as profit/loss - not "
                          "applied again", IntegerToString((long)tk[i]), eff[i],
                          TimeToString(tm[i], TIME_DATE | TIME_SECONDS)), true);
  }

// applies the new cash deals newer than the cursor that are not late (one cash flow); the cursor moves past every
// new cash deal
void ApplyNewCash(const ulong &tk[], const long &type[], const double &eff[], const int &late[], const double eq)
  {
   double flow = 0.0;
   int count = 0;
   ulong mx = g_flowTicket;
   for(int i = 0; i < ArraySize(tk); i++)
     {
      if(!IsCashFlow(type[i]) || tk[i] <= g_flowTicket)
         continue;
      if(tk[i] > mx)
         mx = tk[i];
      if(late[i] != 0)
         continue;
      flow += eff[i];
      count++;
     }
   if(count > 0)
      ApplyCashFlow(flow, count, eq);
   if(mx != g_flowTicket)
     {
      g_flowTicket = mx;
      g_stateDirty = true;
     }
  }

// the reconciliation reference moves to balance + credit 'money' and the newest deal of this read
void SetFlowReference(const double money, const ulong newest, const datetime newestTime)
  {
   if(!g_refKnown || money != g_moneyRef || newest > g_dealRef)
      g_flowScan = TimeCurrent();   // only when the reference moves (no persisted change while nothing happens)
   g_moneyRef = money;
   if(!g_refKnown || newest > g_dealRef)
     {
      if(newest > g_dealRef)
         g_dealRef = newest;
      g_dealRefTime = (newestTime > 0) ? newestTime : TimeCurrent();
     }
   g_refKnown = true;
  }

// rescale every equity baseline by k = E / (E - F) so that the percentage guards (DD scaling, max-DD halt,
// daily limit, monthly stop, vol target / equity filter) stay exactly where they were before the flow
void ApplyCashFlow(const double flow, const int count, const double eq)
  {
   g_stateDirty = true;
   if(flow == 0.0)
     {
      Log(StringFormat("CASH FLOW: %d deals netting to 0 detected, guards unchanged", count));
      return;
     }
   double before = eq - flow;
   double k = (before > 0.0) ? eq / before : 0.0;
   string how = "";
   if(k >= 0.02 && k <= 50.0)
     {
      g_peak *= k;
      g_dayStartEq *= k;
      g_monthStartEq *= k;
      g_lastEq *= k;
      for(int i = 0; i < ArraySize(g_dailyEq); i++)
         g_dailyEq[i] *= k;
      how = StringFormat("x%.4f", k);
     }
   else
     {
      g_peak = eq;
      g_dayStartEq = eq;
      g_monthStartEq = eq;
      g_lastEq = eq;
      for(int i = 0; i < ArraySize(g_dailyEq); i++)
         g_dailyEq[i] = eq;
      how = "rebased to current equity";
     }
   if(count > 1)
      how += StringFormat(", %d deals", count);
   Log(StringFormat("CASH FLOW %+.2f detected, guards rebased (%s)", flow, how), true);
  }

// Amount-based reconciliation (shared rule with the Python engine). Every cycle (live only):
//  1. the deals newer than the reference deal are read (any type); balance + credit M is read before and after
//     the read: when it moved meanwhile the cycle is pending and decided on the next one
//  2. reconciled when M - reference money equals the sum of their effects (profit + commission + swap + fee)
//     within max(0.02, 1e-6 x M): the new cash deals (balance / credit / bonus) are applied as cash flows (k =
//     E / (E - F), E read after the deal read), trade deals are profit / loss; the reference moves to M and the
//     newest deal
//  3. else new cash deals that match a change counted as profit / loss earlier (absorbed record) and, left out,
//     make the sums agree are late deals of that change: marked as seen, not applied again (notified)
//  4. else pending (returns false): no peak raise, no halt / month / day stop, no DD alert / day roll, no new
//     entry; closes, time stops, TP management and stops in force continue. After GT_FLOW_PENDING_SEC (the first
//     reconciliation after a start: GT_FLOW_START_SEC) the new cash deals are applied and the rest of the change
//     counts as profit / loss (an absorbed record is kept 7 days, at most GT_ABSORB_MAX)
// A deal history that cannot be read shows no deal: a changed M is pending with the same limit, an unchanged M
// needs nothing (new entries wait while the history cannot be read). eq is read again after the deal read.
bool HandleCashFlows(double &eq)
  {
   g_histBad = false;
   if(g_tester)
      return true;
   double bc = AccountInfoDouble(ACCOUNT_BALANCE) + AccountInfoDouble(ACCOUNT_CREDIT);
   ulong tk[];
   long type[];
   double eff[];
   datetime tm[];
   bool readable = ReadNewDeals(tk, type, eff, tm);
   double eqNow = AccountInfoDouble(ACCOUNT_EQUITY);
   double money = AccountInfoDouble(ACCOUNT_BALANCE) + AccountInfoDouble(ACCOUNT_CREDIT);
   if(MathAbs(money - bc) >= 0.005)
      return false;   // a deal was booked during the read: nothing is decided, the read is repeated next cycle
   if(eqNow > 0.0)
      eq = eqNow;
   if(!readable)
     {
      g_histBad = true;
      if(!g_refKnown)
         return true;   // no reference yet: taken from the first readable read (new entries wait meanwhile)
     }
   int n = ArraySize(tk);
   ulong newest = 0;
   datetime newestTime = 0;
   double sum = 0.0;
   for(int i = 0; i < n; i++)
     {
      sum += eff[i];
      if(tk[i] > newest)
        {
         newest = tk[i];
         newestTime = tm[i];
        }
     }
   int late[];
   ArrayResize(late, n);
   if(n > 0)
      ArrayInitialize(late, 0);
   if(!g_refKnown)
     {
      // state of an earlier 1.2 build (cursor, no reference): the cash deals newer than the cursor are applied
      // as before and this read becomes the reference (no priming again)
      ApplyNewCash(tk, type, eff, late, eq);
      if(newest > g_flowTicket)
         SetFlowReference(money, newest, newestTime);
      else
         SetFlowReference(money, g_flowTicket, 0);
      g_pendingSince = 0;
      g_firstRecon = false;
      g_stateDirty = true;
      Log(StringFormat("cash-flow reference taken: balance + credit %.2f, deal #%s", money,
                       IntegerToString((long)g_dealRef)));
      return true;
     }
   PruneAbsorbed();
   double delta = money - g_moneyRef;
   double tol = MathMax(0.02, 1e-6 * MathAbs(money));
   bool ok = (MathAbs(delta - sum) <= tol);
   if(!ok && readable)
      ok = MatchLateDeals(tm, eff, delta, sum, tol, late);
   datetime now = TimeLocal();
   if(ok)
     {
      if(g_pendingSince != 0)
         Log(StringFormat("balance/credit change %+.2f explained by the deal history after %d s", delta,
                          (int)Secs(now, g_pendingSince)));
      NoteLateDeals(tk, type, eff, tm, late);
      ApplyNewCash(tk, type, eff, late, eq);
      SetFlowReference(money, newest, newestTime);
      g_pendingSince = 0;
      if(readable)
         g_firstRecon = false;
      return true;
     }
   if(g_pendingSince == 0 || Secs(now, g_pendingSince) < 0)
     {
      g_pendingSince = now;
      g_pendingWin = g_firstRecon ? GT_FLOW_START_SEC : GT_FLOW_PENDING_SEC;
      Log(StringFormat("balance/credit changed by %+.2f, the new deals explain %+.2f%s: waiting up to %d s for the "
                       "matching deal (no stop decision and no new entry meanwhile)", delta, sum,
                       readable ? "" : " (the deal history cannot be read)", g_pendingWin));
     }
   if(Secs(now, g_pendingSince) <= g_pendingWin)
      return false;
   // limit reached: late deals (booked before an earlier absorbed change) are left out, the other new cash deals
   // are applied, the rest of the change counts as profit / loss
   int nl = 0;
   double sx = 0.0;
   if(n > 0)
      sx = MarkLateDeals(tm, eff, true, late, nl);
   NoteLateDeals(tk, type, eff, tm, late);
   ApplyNewCash(tk, type, eff, late, eq);
   double unexplained = delta - (sum - sx);
   Log(StringFormat("balance/credit changed by %+.2f without a matching deal in the history: treated as profit/loss",
                    unexplained), true);
   AddAbsorbed(unexplained);
   SetFlowReference(money, newest, newestTime);
   g_pendingSince = 0;
   g_firstRecon = false;   // the start-up window ends at the first limit, readable history or not (Python: same)
   return true;
  }

//+------------------------------------------------------------------+
//| Broker clock verification (live only; the tester uses the rule)   |
//+------------------------------------------------------------------+
// an advance of the server time counts as a new tick only when it is not larger than the local time that passed
// since the previous server time was first seen (+ GT_CLOCK_ADV_SEC): the jump from an old cached time to Friday's
// last tick after a weekend terminal start is no new tick, while the first tick after a quiet minute or the weekly
// open (the server time moved as far as the local clock) is one
void TrackServerTime(const datetime srv)
  {
   if(srv <= g_lastSrvSeen)
      return;
   datetime now = TimeLocal();
   if(g_lastSrvSeen > 0 && Secs(srv, g_lastSrvSeen) <= Secs(now, g_lastSrvSeenAt) + GT_CLOCK_ADV_SEC)
      g_srvAdvAt = now;
   g_lastSrvSeen = srv;
   g_lastSrvSeenAt = now;
  }

// clock observation from the newest tick (same rule as the Python engine):
//  1 = valid: obs = server - UTC rounded to 30 min
//  0 = no observation: the server time did not advance within GT_CLOCK_ADV_SEC (weekend, holiday, frozen feed,
//      a stale Friday tick after a restart never counts)
// -1 = fresh tick, but server - PC UTC is not within GT_CLOCK_TOL_SEC of a whole half-hour offset within +-14 h:
//      the PC clock is off (diff = server - PC UTC in seconds)
int ObserveOffset(long &obs, long &diff)
  {
   obs = 0;
   diff = 0;
   datetime srv = TimeCurrent();
   datetime gmt = TimeGMT();
   if(srv <= 0 || gmt <= 0)
      return 0;
   datetime now = TimeLocal();
   if(g_srvAdvAt == 0 || Secs(now, g_srvAdvAt) > GT_CLOCK_ADV_SEC || Secs(now, g_srvAdvAt) < 0)
      return 0;
   diff = (long)srv - (long)gmt;
   long nearest = (long)MathRound((double)diff / 1800.0) * 1800;
   if(MathAbs((double)(diff - nearest)) > GT_CLOCK_TOL_SEC || MathAbs((double)nearest) > 14.0 * 3600.0)
      return -1;
   obs = nearest;
   return 1;
  }

// AUTO waits for a verified clock after every start-up; every mode blocks after GT_CLOCK_CONFIRM mismatches
bool ClockAllowsEntries()
  {
   if(g_tester)
      return true;
   if(g_clkBlocked)
      return false;
   return (g_clockMode != GT_SERVER_AUTO || g_clkVerified);
  }

string ClockBlockReason()
  {
   if(g_clkBlocked)
      return "broker clock mismatch";
   if(g_clkOffGridN >= GT_CLOCK_CONFIRM)
      return "broker clock not verified yet (PC clock off - check the Windows time synchronisation)";
   return "broker clock not verified yet";
  }

// gates for every new entry that do not depend on the signal: the broker clock, the first-run deal history and
// an unexplained balance change in this cycle (closes, stops and TP management are never gated)
bool EntryGateOpen(string &why)
  {
   why = "";
   if(!ClockAllowsEntries())
      why = ClockBlockReason();
   else
      if(!g_flowPrimed)
         why = "deal history not confirmed complete yet (first run)";
      else
         if(g_histBad)
            why = "the deal history cannot be read";
         else
            if(g_flowPending)
               why = "balance change not in the deal history yet (cash flow pending)";
   return (why == "");
  }

// AUTO: adopts an observed offset. When it equals the NY7 rule's offset at this moment, the NY7 rule itself is
// adopted (the clock then follows US DST without a mismatch at each switch, as Python's detect_server_mode);
// any other offset is kept as a fixed number of seconds
void AdoptOffset(const long obs, const string how)
  {
   bool had = g_clkHave;
   string old = ClockText();
   g_clkOffset = obs;
   g_clkHave = true;
   g_clkNY7 = (obs == NY7Offset(TimeCurrent()));
   g_clkVerified = true;
   g_clkBlocked = false;
   g_clkMismatch = 0;
   g_clkCandN = 0;
   g_stateDirty = true;
   if(!had)
      Log(StringFormat("broker clock measured: server = UTC%+.1f h now, clock in use: %s (AUTO, %s); new entries "
                       "enabled", obs / 3600.0, ClockText(), how), true);
   else
      Log(StringFormat("broker clock changed: %s -> %s (server = UTC%+.1f h now; AUTO, %s)", old, ClockText(),
                       obs / 3600.0, how), true);
  }

void ClockMatch(const long obs)
  {
   bool wasBlocked = g_clkBlocked;
   bool wasVerified = g_clkVerified;
   g_clkVerified = true;
   g_clkBlocked = false;
   g_clkMismatch = 0;
   g_clkCandN = 0;
   if(wasBlocked)
      Log(StringFormat("broker clock matches again (UTC%+.1f h, %s): new entries re-enabled", obs / 3600.0,
                       ClockText()), true);
   else
      if(!wasVerified)
         Log(StringFormat("broker clock verified: server = UTC%+.1f h (%s, %s)", obs / 3600.0, EnumToString(g_clockMode),
                          ClockText()));
  }

// a fresh tick off the half-hour grid is no observation of the broker clock: the PC clock is off. Reported after
// GT_CLOCK_CONFIRM such observations in a row, then at most every GT_REPEAT_SEC
void ClockOffGrid(const long diff)
  {
   long nearest = (long)MathRound((double)diff / 1800.0) * 1800;
   g_clkOffGridSec = (MathAbs((double)nearest) > 14.0 * 3600.0) ? diff : diff - nearest;
   g_clkOffGridN++;
   if(g_clkOffGridN < GT_CLOCK_CONFIRM)
      return;
   datetime now = TimeLocal();
   if(g_clkDriftNote != 0 && Secs(now, g_clkDriftNote) < GT_REPEAT_SEC && Secs(now, g_clkDriftNote) >= 0)
      return;
   g_clkDriftNote = now;
   string effect = (g_clockMode == GT_SERVER_AUTO && !g_clkVerified) ?
                   "new entries wait until the broker clock is verified" : "trading continues with the clock in use";
   Log(StringFormat("PC CLOCK: server time %s vs PC clock %s UTC is %+d s off a whole half-hour offset (%d observations "
                    "in a row) - check the Windows time synchronisation; %s",
                    TimeToString(TimeCurrent(), TIME_DATE | TIME_SECONDS), TimeToString(TimeGMT(), TIME_DATE | TIME_SECONDS),
                    (int)g_clkOffGridSec, g_clkOffGridN, effect), true);
  }

// one counted observation per minute (the first one at once), only from a fresh tick. Gating of new entries
// (shared rule with the Python engine, spec section 3):
//  - AUTO: new entries wait until a valid observation after start-up confirms the clock in use (the adopted /
//    persisted clock, or the NY7 rule when there is none). A different offset is adopted after GT_CLOCK_CONFIRM
//    identical observations - the first offset too, unless it matches the NY7 rule. An adopted offset that equals
//    the NY7 rule's offset at that moment is kept as the NY7 rule (follows US DST), any other as fixed seconds.
//  - NY7 / Fixed: new entries are allowed from the start.
//  - every mode: GT_CLOCK_CONFIRM consecutive mismatches that are not adopted block new entries until the clock
//    matches again.
// Closes, time stops, TP management and hard stops always run with the clock in use.
void CheckClock()
  {
   if(g_tester)
      return;
   datetime now = TimeLocal();
   if(g_clkLastObs != 0 && Secs(now, g_clkLastObs) < GT_CLOCK_OBS_SEC && Secs(now, g_clkLastObs) >= 0)
      return;
   long obs = 0;
   long diff = 0;
   int r = ObserveOffset(obs, diff);
   if(r == 0)
      return;   // no fresh tick: no observation, keep the last verdict
   g_clkLastObs = now;
   if(r < 0)
     {
      ClockOffGrid(diff);
      return;
     }
   g_clkOffGridN = 0;
   datetime srv = TimeCurrent();
   long expected = (long)srv - (long)ServerToUTC(srv);   // clock in use (AUTO without an offset: NY7 rule)
   bool autoMode = (g_clockMode == GT_SERVER_AUTO);
   if(obs == expected)
     {
      if(autoMode && !g_clkHave)
         AdoptOffset(obs, "matches the NY7 rule");
      else
         ClockMatch(obs);
      return;
     }
   g_clkMismatch++;
   if(autoMode)
     {
      if(g_clkCandN > 0 && obs == g_clkCand)
         g_clkCandN++;
      else
        {
         g_clkCand = obs;
         g_clkCandN = 1;
        }
      Log(StringFormat("broker clock observation UTC%+.1f h differs from UTC%+.1f h in use (%s; %d/%d identical)",
                       obs / 3600.0, expected / 3600.0, ClockText(), g_clkCandN, GT_CLOCK_CONFIRM));
      if(g_clkCandN >= GT_CLOCK_CONFIRM)
        {
         AdoptOffset(obs, IntegerToString(GT_CLOCK_CONFIRM) + " identical observations");
         return;
        }
     }
   else
      if(g_clkMismatch <= GT_CLOCK_CONFIRM || InpVerbose)
         Log(StringFormat("broker clock observation %+.1f h differs from the configured %+.1f h (%d/%d)", obs / 3600.0,
                          expected / 3600.0, g_clkMismatch, GT_CLOCK_CONFIRM));
   if(g_clkMismatch >= GT_CLOCK_CONFIRM && !g_clkBlocked)
     {
      g_clkBlocked = true;
      if(autoMode)
         Log(StringFormat("broker clock unstable: observations disagree with UTC%+.1f h in use - new entries blocked; "
                          "closes and stops keep working", expected / 3600.0), true);
      else
         Log(StringFormat("broker clock mismatch: observed %+.1f h, expected %+.1f h (InpServerTime=%s). New entries "
                          "blocked; closes and stops keep working. Use GT_SERVER_AUTO or correct the setting / PC clock.",
                          obs / 3600.0, expected / 3600.0, EnumToString(InpServerTime)), true);
     }
  }

//+------------------------------------------------------------------+
//| Monitoring (notification only, never changes trading)             |
//+------------------------------------------------------------------+
bool Ready()
  {
   if(g_tester)
      return true;
   return (TerminalInfoInteger(TERMINAL_CONNECTED) != 0 && AccountInfoInteger(ACCOUNT_LOGIN) > 0 &&
           AccountInfoDouble(ACCOUNT_EQUITY) > 0.0);
  }

void MonitorConnection()
  {
   if(g_tester)
      return;
   datetime now = TimeLocal();
   if(TerminalInfoInteger(TERMINAL_CONNECTED) != 0)
     {
      if(g_discNotified)
         Log("connection to the trade server restored", true);
      g_discSince = 0;
      g_discNotified = false;
      return;
     }
   if(g_discSince == 0)
      g_discSince = now;
   if(Secs(now, g_discSince) >= 600 && (!g_discNotified || Secs(now, g_discNote) >= GT_REPEAT_SEC))
     {
      Log(StringFormat("DISCONNECTED from the trade server for %d min", (int)(Secs(now, g_discSince) / 60)), true);
      g_discNotified = true;
      g_discNote = now;
     }
  }

// run-time permission checks; while trading is blocked no close or entry is sent, state keeps updating
bool TradingPermitted(string &why)
  {
   why = "";
   if(g_tester)
      return true;
   if(TerminalInfoInteger(TERMINAL_CONNECTED) == 0)
      why = "terminal not connected to the trade server";
   else
      if(TerminalInfoInteger(TERMINAL_TRADE_ALLOWED) == 0)
         why = "Algo Trading is disabled in the terminal";
      else
         if(MQLInfoInteger(MQL_TRADE_ALLOWED) == 0)
            why = "'Allow Algo Trading' is unchecked in the EA properties";
         else
            if(AccountInfoInteger(ACCOUNT_TRADE_ALLOWED) == 0)
               why = "trading is disabled for this account (investor password?)";
            else
               if(AccountInfoInteger(ACCOUNT_TRADE_EXPERT) == 0)
                  why = "the broker does not allow expert trading on this account";
   int now = (why == "") ? 1 : 0;
   datetime t = TimeLocal();
   if(now != g_permit)
     {
      if(now == 0)
         Log("TRADING BLOCKED: " + why, true);
      else
         if(g_permit == 0)
            Log("trading permitted again", true);
      g_permit = now;
      g_permitNote = t;
     }
   else
      if(now == 0 && Secs(t, g_permitNote) >= GT_REPEAT_SEC)
        {
         Log("TRADING STILL BLOCKED: " + why, true);
         g_permitNote = t;
        }
   return (now == 1);
  }

string StatusText()
  {
   string s = "";
   if(g_halted)
      s += ", HALTED (max DD)";
   if(g_monthHalted)
      s += ", month stop";
   if(g_dayHalted)
      s += ", day stop";
   if(InBlackout())
      s += ", blackout";
   string gate;
   if(!EntryGateOpen(gate))
      s += ", entries blocked: " + gate;
   if(NoSLBlocks())
      s += ", entries blocked: own position without stop loss";
   if(g_permit == 0)
      s += ", trading blocked";
   if(s == "")
      return "ok";
   return StringSubstr(s, 2);
  }

void CheckDDAlert(const double eq)
  {
   if(g_tester || InpDDAlert <= 0.0 || eq <= 0.0)
      return;
   double dd = Drawdown(eq);
   if(dd * 100.0 < InpDDAlert || g_ddAlertDay == g_day)
      return;
   g_ddAlertDay = g_day;   // at most once per market day while above the level
   Log(StringFormat("DD ALERT: drawdown %.1f%% from peak %.2f (equity %.2f; alert at %.1f%%, halt at %.1f%%)",
                    dd * 100.0, g_peak, eq, InpDDAlert, InpMaxDDHalt), true);
  }

// our deals of the market day mday (entries opened, exits closed, net P/L incl. swap and commission)
void CountDayTrades(const datetime mday, int &opened, int &closed, double &pl)
  {
   opened = 0;
   closed = 0;
   pl = 0.0;
   long fromL = (long)mday - 3 * 86400;
   if(fromL < 0)
      fromL = 0;
   if(!HistorySelect((datetime)fromL, (datetime)((long)mday + 3 * 86400)))
      return;
   int n = HistoryDealsTotal();
   long ids[];
   int nid = 0;
   for(int i = 0; i < n; i++)
     {
      ulong tk = HistoryDealGetTicket(i);
      if(tk == 0)
         continue;
      if(IsOurMagic(HistoryDealGetInteger(tk, DEAL_MAGIC)) && HistoryDealGetInteger(tk, DEAL_ENTRY) == DEAL_ENTRY_IN)
        {
         ArrayResize(ids, nid + 1);
         ids[nid] = HistoryDealGetInteger(tk, DEAL_POSITION_ID);
         nid++;
        }
     }
   for(int i = 0; i < n; i++)
     {
      ulong tk = HistoryDealGetTicket(i);
      if(tk == 0)
         continue;
      long type = HistoryDealGetInteger(tk, DEAL_TYPE);
      if(type != DEAL_TYPE_BUY && type != DEAL_TYPE_SELL)
         continue;
      bool ours = IsOurMagic(HistoryDealGetInteger(tk, DEAL_MAGIC));
      long pid = HistoryDealGetInteger(tk, DEAL_POSITION_ID);
      for(int j = 0; j < nid && !ours; j++)
         if(ids[j] == pid)
            ours = true;
      if(!ours)
         continue;
      datetime dt = (datetime)HistoryDealGetInteger(tk, DEAL_TIME);
      if(DayStart(ServerToMarket(dt)) != mday)
         continue;
      if(HistoryDealGetInteger(tk, DEAL_ENTRY) == DEAL_ENTRY_IN)
         opened++;
      else
         closed++;
      pl += HistoryDealGetDouble(tk, DEAL_PROFIT) + HistoryDealGetDouble(tk, DEAL_SWAP) +
            HistoryDealGetDouble(tk, DEAL_COMMISSION);
     }
  }

// at each market-day change (live): equity, DD, month-to-date flow-adjusted return, trades of the day, state
void DailySummary(const double eq)
  {
   if(!g_sumPending)
      return;
   g_sumPending = false;
   if(g_tester)
      return;
   int opened = 0;
   int closed = 0;
   double pl = 0.0;
   CountDayTrades(g_sumDay, opened, closed, pl);
   Log(StringFormat("DAILY %s: equity %.2f, DD %.2f%%, month-to-date %+.2f%% (flow-adjusted), "
                    "trades %d opened / %d closed, P/L %.2f, state: %s",
                    TimeToString(g_sumDay, TIME_DATE), eq, Drawdown(eq) * 100.0, g_sumMonthRet * 100.0,
                    opened, closed, pl, StatusText()), true);
  }

// FX market days in market time (NY+7): Monday to Friday, without Dec 25 and Jan 1
bool IsMarketDay(const datetime mkt)
  {
   MqlDateTime s;
   TimeToStruct(mkt, s);
   if(s.day_of_week == 0 || s.day_of_week == 6)
      return false;
   return !((s.mon == 12 && s.day == 25) || (s.mon == 1 && s.day == 1));
  }

bool MarketOpenNow()
  {
   return IsMarketDay(UTCToMarket(TimeGMT()));
  }

// local time of 00:00 market time of the current market day when the market was closed the day before (Monday
// after the weekend, the day after Dec 25 / Jan 1), else 0 (Python _session_open_utc)
datetime SessionOpenLocal()
  {
   datetime mkt = UTCToMarket(TimeGMT());
   if(IsMarketDay(mkt - 86400))
      return 0;
   return (datetime)((long)TimeLocal() - ((long)mkt - (long)DayStart(mkt)));
  }

// stale-feed watchdog (shared rule with the Python engine): no new quote for GT_STALE_FEED_SEC on a market day,
// counted from the last advance of the server time (or the start) - but on the first market day after a closed day
// never from before that day's 00:00 market time, plus GT_SESSION_GRACE_SEC for a late first quote
void CheckStaleFeed()
  {
   if(g_tester || TerminalInfoInteger(TERMINAL_CONNECTED) == 0)
      return;
   datetime now = TimeLocal();
   datetime since = (g_srvAdvAt > g_startLocal) ? g_srvAdvAt : g_startLocal;
   datetime ref = since;
   datetime opened = SessionOpenLocal();
   if(opened != 0 && since < opened)
     {
      since = opened;
      ref = (datetime)((long)opened + GT_SESSION_GRACE_SEC);
     }
   bool stale = (Secs(now, ref) > GT_STALE_FEED_SEC && MarketOpenNow());
   if(stale)
     {
      if(!g_staleNotified || Secs(now, g_staleNote) >= GT_REPEAT_SEC)
        {
         Log(StringFormat("STALE FEED: no new quote for %d min while the market should be open (last server time %s)",
                          (int)(Secs(now, since) / 60), TimeToString(g_lastSrvSeen, TIME_DATE | TIME_MINUTES)), true);
         g_staleNotified = true;
         g_staleNote = now;
        }
     }
   else
      if(g_staleNotified && g_srvAdvAt > g_staleNote)
        {
         Log("quotes are coming in again", true);
         g_staleNotified = false;
        }
  }

//+------------------------------------------------------------------+
//| Single instance per account                                       |
//+------------------------------------------------------------------+
string LockName(const long login)
  {
   return "GT_" + IntegerToString(login) + "_lock";
  }

// 1 = lock held, 0 = account not known yet (retry later), -1 = held by another live instance
int AcquireLock()
  {
   if(g_tester)
      return 1;
   long login = AccountInfoInteger(ACCOUNT_LOGIN);
   if(login <= 0)
      return 0;
   if(g_lockToken <= 0.0)
     {
      long cid = ChartID();
      if(cid < 0)
         cid = -cid;
      g_lockToken = 1.0 + (double)(cid % 1000000000);   // per chart; kept across chart/parameter changes
     }
   string nm = LockName(login);
   string hb = nm + "hb";
   double holder = 0.0;
   if(GlobalVariableCheck(nm))
      holder = GlobalVariableGet(nm);
   else
     {
      GlobalVariableTemp(nm);   // temporary: never written to disk, gone when the terminal stops
      GlobalVariableSet(nm, 0.0);
     }
   double beat = 0.0;
   if(GlobalVariableCheck(hb))
      beat = GlobalVariableGet(hb);
   bool fresh = (beat > 0.0 && MathAbs((double)TimeLocal() - beat) <= GT_LOCK_STALE_SEC);
   if(holder != 0.0 && holder != g_lockToken && fresh)
      return -1;
   if(holder != g_lockToken && !GlobalVariableSetOnCondition(nm, g_lockToken, holder))
      return -1;
   if(!GlobalVariableCheck(hb))
      GlobalVariableTemp(hb);
   GlobalVariableSet(hb, (double)TimeLocal());
   g_lockHeld = true;
   g_lockLogin = login;
   g_lockBeat = TimeLocal();
   return 1;
  }

// stops this copy (and returns false) when another instance holds the lock; the losing copy does not save state
void StopThisCopy(const string msg)
  {
   g_stopping = true;
   g_lockHeld = false;
   g_stateLoaded = false;
   Log(msg, true);
   FlushNotify(true);
   ExpertRemove();
  }

bool LockHeartbeat()
  {
   if(g_tester || !g_lockHeld)
      return true;
   datetime now = TimeLocal();
   if(Secs(now, g_lockBeat) < GT_LOCK_BEAT_SEC && Secs(now, g_lockBeat) >= 0)
      return true;
   string nm = LockName(g_lockLogin);
   double holder = 0.0;
   if(GlobalVariableCheck(nm))
      holder = GlobalVariableGet(nm);
   if(holder != g_lockToken)
     {
      if(holder != 0.0)
        {
         StopThisCopy("another GreatestTrader instance took over this account - this copy stops");
         return false;
        }
      g_lockHeld = false;   // lock deleted by hand: take it again
      if(AcquireLock() < 0)
        {
         StopThisCopy("another GreatestTrader instance runs on this account - this copy stops");
         return false;
        }
      return true;
     }
   GlobalVariableSet(nm + "hb", (double)now);
   g_lockBeat = now;
   return true;
  }

void ReleaseLock()
  {
   if(g_tester || !g_lockHeld)
      return;
   string nm = LockName(g_lockLogin);
   if(GlobalVariableCheck(nm) && GlobalVariableGet(nm) == g_lockToken)
     {
      GlobalVariableSet(nm, 0.0);
      if(GlobalVariableCheck(nm + "hb"))
         GlobalVariableSet(nm + "hb", 0.0);
     }
   g_lockHeld = false;
  }

//+------------------------------------------------------------------+
//| Start-up: state is loaded on the first Ready() cycle               |
//+------------------------------------------------------------------+
// InpResetHalt: clears the max-DD halt and rebases the peak once; a persisted marker stops a forgotten
// InpResetHalt=true from clearing a later halt at every restart (re-armed by a start with InpResetHalt=false).
// Called after the first cash-flow scan of the session (ProcessAll): a deposit / withdrawal made while the EA was
// off is applied to the old peak first, then the peak is rebased to the equity that contains it.
void ApplyResetHalt(const double eq)
  {
   if(g_tester)
      return;
   if(!InpResetHalt)
     {
      g_resetHaltDone = false;
      return;
     }
   if(g_resetHaltDone)
     {
      Log("InpResetHalt=true was already applied: set it back to false (the halt is not cleared again)", true);
      return;
     }
   bool was = g_halted;
   double oldPeak = g_peak;
   g_halted = false;
   g_peak = eq;
   g_resetHaltDone = true;
   g_stateDirty = true;
   Log(StringFormat("RESET HALT (InpResetHalt): halt %s -> off, peak %.2f -> %.2f (current equity); other state kept. "
                    "Set InpResetHalt back to false.", was ? "on" : "off", oldPeak, eq), true);
  }

bool EnsureState()
  {
   if(g_stateLoaded)
      return true;
   long login = AccountInfoInteger(ACCOUNT_LOGIN);
   if(!g_tester)
     {
      // the margin mode is reliable only after authorisation (netting = 0 before it), hence checked here too
      if(AccountInfoInteger(ACCOUNT_MARGIN_MODE) != ACCOUNT_MARGIN_MODE_RETAIL_HEDGING)
        {
         Log("NETTING / exchange account: GreatestTrader needs a HEDGING account (on netting, closing the EA position "
             "would also close manual or other-EA volume on the same symbol). The EA stops.", true);
         g_stopping = true;
         FlushNotify(true);
         ExpertRemove();
         return false;
        }
      int lk = AcquireLock();
      if(lk < 0)
        {
         StopThisCopy("another GreatestTrader instance runs on this account - this copy stops");
         return false;
        }
      if(lk == 0)
         return false;
     }
   g_gvPrefix = "GT_" + IntegerToString(login) + "_";
   ArrayResize(g_gvName, 0);
   ArrayResize(g_gvKey, 0);
   ArrayResize(g_gvVal, 0);
   ArrayResize(g_gvOk, 0);
   g_gvRefreshAt = 0;
   g_fileDirty = false;
   ResetStateVars();
   bool flowKnown = false;
   if(!g_tester)
     {
      g_stateLogin = login;
      // the global variables of this account are gone (4-week expiry, deleted): the state file restores them
      if(!GlobalVariableCheck(g_gvPrefix + "peak"))
         RestoreStateFile(login);
      flowKnown = GlobalVariableCheck(g_gvPrefix + "flowtk");
      LoadState();
     }
   double eq = AccountInfoDouble(ACCOUNT_EQUITY);
   if(g_peak <= 0.0)
      g_peak = eq;
   g_flowPrimed = (g_tester || flowKnown);   // first run: TryPrimeFlowCursor (ProcessAll) once the history is complete
   g_resetDue = true;                        // InpResetHalt: after the first cash-flow scan (ProcessAll)
   g_stateLoaded = true;
   g_stateDirty = true;
   if(!g_tester)
     {
      string clk = "none";
      if(g_clkHave)
         clk = g_clkNY7 ? "NY7 rule" : "UTC" + DoubleToString(g_clkOffset / 3600.0, 1) + " h";
      Log(StringFormat("state loaded (%s*): peak %.2f, DD %.1f%%, halted=%s, month stop=%s, persisted broker clock=%s",
                       g_gvPrefix, g_peak, Drawdown(eq) * 100.0, g_halted ? "yes" : "no", g_monthHalted ? "yes" : "no",
                       clk));
     }
   return true;
  }

//+------------------------------------------------------------------+
//| Input validation (parity with Python Config.validate)             |
//+------------------------------------------------------------------+
bool Bad(const string msg)
  {
   Print("[GT] invalid input: ", msg);
   return false;
  }

bool PctOK(const double v)
  {
   return (v >= 0.0 && v <= 100.0);
  }

bool ValidateInputs()
  {
   if(InpRiskProfile != GT_RISK_CONSERVATIVE && InpRiskProfile != GT_RISK_STANDARD &&
      InpRiskProfile != GT_RISK_AGGRESSIVE && InpRiskProfile != GT_RISK_CUSTOM)
      return Bad("InpRiskProfile must be 0..3");
   if(InpServerTime != GT_SERVER_NY7 && InpServerTime != GT_SERVER_FIXED && InpServerTime != GT_SERVER_AUTO)
      return Bad("InpServerTime must be 0 (NY7), 1 (Fixed) or 2 (Auto)");
   if(BaseRisk(true) < 0.0 || BaseRisk(true) > 0.05 + 1e-12 || BaseRisk(false) < 0.0 || BaseRisk(false) > 0.05 + 1e-12)
      return Bad("risk per trade (InpRiskNR / InpRiskES) must be between 0 and 5 percent");
   if(InpBBPeriod < 2 || InpATRPeriod < 2 || InpMaxHoldBars < 1 || InpESATRPeriodH1 < 1)
      return Bad("indicator periods must be >= 2 (ES ATR >= 1) and InpMaxHoldBars >= 1");
   if(InpBBDev <= 0.0 || InpSLATRMult <= 0.0 || InpESSLATRMult <= 0.0 || InpATRCostMult < 0.0)
      return Bad("InpBBDev, InpSLATRMult and InpESSLATRMult must be > 0, InpATRCostMult >= 0");
   if(InpMaxOpen < 1 || InpMaxPerCurrency < 1)
      return Bad("InpMaxOpen and InpMaxPerCurrency must be >= 1");
   if(InpMaxSameDirPerCcy < 0 || InpVolLookbackDays < 0 || InpEqFilterDays < 0)
      return Bad("InpMaxSameDirPerCcy, InpVolLookbackDays and InpEqFilterDays must be >= 0");
   if(!PctOK(InpMaxTotalRisk) || !PctOK(InpDailyLossLimit) || !PctOK(InpDailyHardStop) || !PctOK(InpMonthlyLossLimit) ||
      !PctOK(InpMonthlyHardStop) || !PctOK(InpMaxDDHalt) || !PctOK(InpDDScaleFull) || !PctOK(InpVolTargetDaily) ||
      !PctOK(InpDDAlert))
      return Bad("percentage limits (total risk, daily/monthly limits and stops, max DD halt, DD scaling, vol target, "
                 "DD alert) must be between 0 and 100");
   if(InpDDScaleFloor < 0.0 || InpDDScaleFloor > 1.0 || InpEqFilterMult < 0.0 || InpEqFilterMult > 1.0)
      return Bad("InpDDScaleFloor and InpEqFilterMult must be between 0 and 1");
   if(InpVolMultMin < 0.0 || InpVolMultMin > InpVolMultMax)
      return Bad("need 0 <= InpVolMultMin <= InpVolMultMax");
   if(InpMaxLotsPerOrder < 0.0 || InpMaxRiskAmount < 0.0)
      return Bad("InpMaxLotsPerOrder and InpMaxRiskAmount must be >= 0 (0 = off)");
   if(InpEntryHour1 < 0 || InpEntryHour1 > 23 || InpEntryHour2 < -1 || InpEntryHour2 > 23)
      return Bad("NR entry hours must be 0..23 (InpEntryHour2 may be -1)");
   if(InpMaxBandZ < 0.0 || InpMaxBarRangeATR < 0.0)
      return Bad("news filters InpMaxBandZ / InpMaxBarRangeATR must be >= 0 (0 = off)");
   if(InpNRSlippagePips < 0.0 || InpNRMaxSpreadPips < 0.0 || InpESMaxSpreadPips < 0.0)
      return Bad("slippage and max spread inputs must be >= 0");
   if(!(0 <= InpESEntryUTC && InpESEntryUTC < InpESExitUTC && InpESExitUTC <= 23))
      return Bad("need 0 <= InpESEntryUTC < InpESExitUTC <= 23");
   if(InpESDirection != -1 && InpESDirection != 1)
      return Bad("InpESDirection must be -1 (sell) or 1 (buy)");
   if(InpNRMagic <= 0 || InpESMagic <= 0 || InpNRMagic == InpESMagic)
      return Bad("InpNRMagic and InpESMagic must be > 0 and different (magic 0 = manual trades)");
   if(InpDeviationPoints < 0 || InpCommissionPerLot < 0.0)
      return Bad("InpDeviationPoints and InpCommissionPerLot must be >= 0");
   if(InpServerTime == GT_SERVER_FIXED)
     {
      double h2 = InpServerGMTOffset * 2.0;
      if(InpServerGMTOffset < -12.0 || InpServerGMTOffset > 14.0 || MathAbs(h2 - MathRound(h2)) > 1e-9)
         return Bad("InpServerGMTOffset must be within -12..+14 hours in steps of 0.5");
     }
   if(!ParseSymbolMult())
      return false;
   for(int i = 0; i < ArraySize(g_multVal); i++)
      if(g_multVal[i] < 0.0 || BaseRisk(true) * g_multVal[i] > 0.05 + 1e-12 || BaseRisk(false) * g_multVal[i] > 0.05 + 1e-12)
         return Bad("InpSymbolRiskMult: " + g_multSym[i] + " must be >= 0 and risk x multiplier must be <= 5 percent");
   g_boStart = ParseMMDD(InpBlackoutStart);
   g_boEnd = ParseMMDD(InpBlackoutEnd);
   if((StringLen(InpBlackoutStart) > 0 && g_boStart == 0) || (StringLen(InpBlackoutEnd) > 0 && g_boEnd == 0))
      return Bad("blackout start/end must be MM-DD (e.g. 12-20) or empty");
   if((g_boStart == 0) != (g_boEnd == 0))
      return Bad("blackout start/end must both be MM-DD or both empty");
   return true;
  }

//+------------------------------------------------------------------+
//| Main cycle                                                        |
//+------------------------------------------------------------------+
void ProcessAll()
  {
   if(g_stopping || !LockHeartbeat())
      return;
   if(!Ready())
     {
      MonitorConnection();
      return;   // terminal not connected / not authorised / equity 0: no state change, no save, no orders
     }
   MonitorConnection();
   if(!EnsureState())
      return;
   datetime nowSrv = TimeCurrent();
   if(nowSrv <= 0)
      return;
   TrackServerTime(nowSrv);
   double eq = AccountInfoDouble(ACCOUNT_EQUITY);
   if(eq <= 0.0)
      return;
   // cash flows are reconciled BEFORE the equity guards of this cycle (eq is read again after the deal read).
   // Pending (the new deals do not explain the balance / credit change yet, at most GT_FLOW_PENDING_SEC, 300 s
   // after a start): no peak raise, no halt / month / day stop decision and no new entry this cycle; closes, time
   // stops and TP management run.
   if(!g_flowPrimed)
      TryPrimeFlowCursor();
   g_flowPending = (g_flowPrimed && !HandleCashFlows(eq));
   if(g_resetDue && g_flowPrimed && !g_flowPending && !g_histBad)
     {
      g_resetDue = false;
      ApplyResetHalt(eq);   // after the first cash-flow scan of the session
     }
   CheckClock();
   PruneFails();
   if(!g_flowPending)
     {
      UpdateEquityState(eq, nowSrv);
      CheckDDAlert(eq);
      DailySummary(eq);
     }
   string why;
   if(TradingPermitted(why))
     {
      // while a hard stop is in force our positions must stay flat (also retries failed closes)
      if(g_flatten)
         CloseAllOurs(g_flattenReason);
      else
         if(g_monthHalted || g_dayHalted)
            CloseAllOurs(g_monthHalted ? "monthly hard stop" : "daily hard stop");
      if(InpNREnabled && g_nsym > 0)
         ProcessNR(nowSrv, eq);
      if(InpESEnabled && g_esOk)
         ProcessES(nowSrv, eq);
     }
   CheckStaleFeed();
   SaveState();
  }

//+------------------------------------------------------------------+
int OnInit()
  {
   g_tester = (bool)MQLInfoInteger(MQL_TESTER);
   g_stopping = false;
   g_stateLoaded = false;   // (re)loaded from the global variables on the first Ready() cycle
   g_startLocal = TimeLocal();
   g_clockMode = (g_tester && InpServerTime == GT_SERVER_AUTO) ? GT_SERVER_NY7 : InpServerTime;
   g_clkVerified = false;   // AUTO: the clock must be confirmed by a live observation after every start-up
   g_clkBlocked = false;
   g_clkMismatch = 0;
   g_clkCandN = 0;
   g_clkLastObs = 0;
   g_clkOffGridN = 0;
   g_flowPending = false;
   g_permit = -1;

   if(!ValidateInputs())
      return INIT_PARAMETERS_INCORRECT;

   g_trade.SetDeviationInPoints((ulong)InpDeviationPoints);
   g_trade.SetMarginMode();
   g_trade.LogLevel(LOG_LEVEL_ERRORS);

   if((g_tester || Ready()) && AccountInfoInteger(ACCOUNT_MARGIN_MODE) != ACCOUNT_MARGIN_MODE_RETAIL_HEDGING)
     {
      Print("[GT] this account uses NETTING (or exchange) position accounting. GreatestTrader requires a HEDGING "
            "account: on netting, closing the EA position would also close manual / other-EA volume on the same symbol.");
      return INIT_FAILED;
     }
   if(!g_tester && AcquireLock() < 0)
     {
      Print("[GT] another GreatestTrader instance is already running on account ", AccountInfoInteger(ACCOUNT_LOGIN),
            " (lock ", LockName(AccountInfoInteger(ACCOUNT_LOGIN)), " held by another chart). Remove the other copy first.");
      return INIT_FAILED;
     }

   // symbols
   string parts[];
   int n = StringSplit(InpNRSymbols, ',', parts);
   ArrayResize(g_sym, 0);
   ArrayResize(g_base, 0);
   g_nsym = 0;
   for(int i = 0; i < n; i++)
     {
      string b = parts[i];
      StringTrimLeft(b);
      StringTrimRight(b);
      StringToUpper(b);
      if(StringLen(b) < 6)
         continue;
      string s = b + InpSymbolSuffix;
      if(!SymbolSelect(s, true))
        {
         Log("WARNING symbol not available: " + s + " (check InpSymbolSuffix) - it is NOT traded", true);
         continue;
        }
      ArrayResize(g_sym, g_nsym + 1);
      ArrayResize(g_base, g_nsym + 1);
      g_sym[g_nsym] = s;
      g_base[g_nsym] = b;
      g_nsym++;
     }
   // process pairs in alphabetical order, like the Python engine and backtester: when several pairs
   // signal on the same bar and a portfolio guard admits only some of them, the same ones are taken
   for(int i = 1; i < g_nsym; i++)
      for(int j = i; j > 0 && StringCompare(g_base[j - 1], g_base[j]) > 0; j--)
        {
         string tb = g_base[j - 1];
         g_base[j - 1] = g_base[j];
         g_base[j] = tb;
         string ts = g_sym[j - 1];
         g_sym[j - 1] = g_sym[j];
         g_sym[j] = ts;
        }
   ArrayResize(g_lastBar, g_nsym);
   ArrayResize(g_defOn, g_nsym);
   ArrayResize(g_defBar, g_nsym);
   ArrayResize(g_defMid, g_nsym);
   ArrayResize(g_defUp, g_nsym);
   ArrayResize(g_defLo, g_nsym);
   ArrayResize(g_defAtr, g_nsym);
   for(int i = 0; i < g_nsym; i++)
     {
      g_lastBar[i] = 0;
      g_defOn[i] = false;
     }

   string eb = InpESSymbol;
   StringToUpper(eb);
   g_esSym = eb + InpSymbolSuffix;
   g_esOk = SymbolSelect(g_esSym, true);
   if(InpESEnabled && !g_esOk)
      Log("WARNING Euro Session symbol not available: " + g_esSym + " - ES is NOT traded", true);

   // warm up history for all symbols (tester downloads data on first request)
   MqlRates tmp[];
   for(int i = 0; i < g_nsym; i++)
      CopyRates(g_sym[i], PERIOD_M15, 0, 50, tmp);
   if(g_esOk)
      CopyRates(g_esSym, PERIOD_H1, 0, 50, tmp);

   EventSetTimer(g_tester ? 60 : (InpTimerSec < 1 ? 1 : InpTimerSec));

   string prof = EnumToString(InpRiskProfile);
   Log(StringFormat("started: %d NR symbols, ES=%s, profile=%s, NR risk=%.2f%% (x InpSymbolRiskMult), ES risk=%.2f%%, "
                    "max lots/order=%.2f, max risk amount=%.2f, max DD halt=%.1f%%, server=%s%s",
                    g_nsym, (InpESEnabled && g_esOk) ? g_esSym : "off", prof, BaseRisk(true) * 100.0,
                    BaseRisk(false) * SymbolMult(g_esSym) * 100.0, InpMaxLotsPerOrder, InpMaxRiskAmount, InpMaxDDHalt,
                    EnumToString(InpServerTime),
                    (!g_tester && g_clockMode == GT_SERVER_AUTO) ? " (new entries wait for a verified broker clock)" : ""),
       true);
   if(!g_tester && TerminalInfoInteger(TERMINAL_TRADE_ALLOWED) == 0)
      Print("[GT] WARNING: Algo Trading is disabled in the terminal.");
   return INIT_SUCCEEDED;
  }

void OnDeinit(const int reason)
  {
   EventKillTimer();
   SaveState(true);   // no-op unless the state was loaded (REASON_INITFAILED cannot overwrite it)
   if(!g_tester && g_stateLoaded &&
      (reason == REASON_REMOVE || reason == REASON_CHARTCLOSE || reason == REASON_TEMPLATE || reason == REASON_PROGRAM ||
       reason == REASON_CLOSE))
     {
      int n = CountOurPositions();
      if(n > 0)
         Log(StringFormat("EA stopped (reason %d) with %d open position(s): time stop / session exit are no longer managed "
                          "(SL/TP stay at the broker)", reason, n), true);
     }
   FlushNotify(true);
   ReleaseLock();
   g_stateLoaded = false;
  }

void OnTick()
  {
   ProcessAll();
  }

void OnTimer()
  {
   ProcessAll();
   FlushNotify();
  }

//+------------------------------------------------------------------+
//| Optimisation criterion: net profit / equity drawdown              |
//+------------------------------------------------------------------+
double OnTester()
  {
   double profit = TesterStatistics(STAT_PROFIT);
   double dd = TesterStatistics(STAT_EQUITY_DD);
   if(dd <= 0.0)
      return profit;
   return profit / dd;
  }
//+------------------------------------------------------------------+
