"""Broker abstraction used by the live engine."""
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from datetime import datetime

import pandas as pd

from ..strategies.base import PositionView

CASH_DEAL_TYPES = (2, 3, 6)  # MT5 DEAL_TYPE_BALANCE, DEAL_TYPE_CREDIT, DEAL_TYPE_BONUS
DEAL_TYPE_CREDIT = 3


class Health(str):
    """broker.health() result: '' when trading decisions are safe, otherwise the reason (a str, so a broker that
    returns a plain string still works). orders_only=True: the terminal is connected and the account data is valid,
    only sending orders is off (Algo Trading switched off, the account does not allow expert trading): the engine
    keeps the cash-flow check and the guards running (peak, day / month / halt latches, DD alert, daily summary)
    but sends no order. A plain string (orders_only False) pauses the whole loop."""
    orders_only: bool

    def __new__(cls, reason: str = "", orders_only: bool = False):
        obj = super().__new__(cls, reason)
        obj.orders_only = bool(orders_only and reason)
        return obj


@dataclass
class SymbolSpec:
    base: str  # e.g. "EURUSD"
    name: str  # broker symbol, e.g. "EURUSD.raw"
    digits: int
    point: float
    pip: float
    volume_min: float
    volume_max: float
    volume_step: float
    stops_level_points: int = 0


@dataclass
class Tick:
    time: datetime  # server time
    bid: float
    ask: float


@dataclass
class OrderResult:
    ok: bool
    ticket: int = 0
    price: float = 0.0
    message: str = ""


@dataclass
class CashFlow:
    """A deposit / withdrawal / credit / bonus booked on the account (not trading profit or loss)."""
    ticket: int  # deal ticket (unique, used for de-duplication)
    time: datetime  # server time
    amount: float  # + deposit, - withdrawal (account currency)
    type: int  # 2 balance, 3 credit, 6 bonus
    comment: str = ""


@dataclass
class Deal:
    """A deal of the account history (any type) with its effect on balance + credit."""
    ticket: int
    time: datetime  # server time
    effect: float  # profit + commission + swap + fee (a CREDIT deal moves the credit: also part of balance + credit)
    type: int  # MT5 DEAL_TYPE_*: 0/1 trades, 2 balance, 3 credit, 6 bonus, others (charge, commission, ...)
    comment: str = ""

    @property
    def cash(self) -> bool:
        """A deposit / withdrawal / credit / bonus (not trading profit or loss)."""
        return int(self.type) in CASH_DEAL_TYPES


@dataclass
class CashScan:
    """One cash-flow check: the deals newer than the engine's reconciliation reference plus ONE account read taken
    AFTER the history read (so that k = E / (E - F) uses an equity that contains every flow the scan found)."""
    flows: list[CashFlow]
    equity: float
    newest_deal: int | None = None  # newest deal ticket of ANY type among `deals`; None = none / unknown
    money: float | None = None  # balance + credit at the account read; None = unknown (no reconciliation)
    scan_money: float | None = None  # balance + credit read just before the history (differs: booked meanwhile)
    balance: float | None = None
    deals: list[Deal] | None = None  # every deal (any type) newer than the reference, in time order; None = unknown


@dataclass
class HistoryCheck:
    """The WHOLE deal history, read for the first-run priming of the cash-flow cursor."""
    flows: list[CashFlow]  # every balance / credit / bonus deal
    complete: bool | None  # the deals add up to the balance (and the credit); None = cannot be checked
    detail: str = ""
    money: float | None = None  # balance + credit read after the deals (the reconciliation reference); None = unknown
    newest_deal: int | None = None  # newest deal ticket of any type in the history (None = no deal)
    newest_time: datetime | None = None  # its server time


@dataclass
class ClosedTrade:
    """Result of a closed position from the deal history."""
    ticket: int  # position ticket
    close_time: datetime  # server time of the (last) exit deal
    close_price: float
    pnl: float  # profit + commission + swap + fee of every deal of the position (account currency)
    reason: str = ""  # "SL", "TP", "stop out", "expert", "manual", ...


class Broker(ABC):
    @abstractmethod
    def connect(self) -> None: ...

    @abstractmethod
    def shutdown(self) -> None: ...

    def reconnect(self) -> None:
        """Drop the connection and connect again (clears cached data)."""
        try:
            self.shutdown()
        finally:
            self.connect()

    def health(self) -> str:
        """'' when trading decisions are safe, otherwise the reason why not (may re-initialise a lost link); a
        Health with orders_only=True when only order sending is off (see Health)."""
        return Health()

    @abstractmethod
    def account_equity(self) -> float: ...

    @abstractmethod
    def account_currency(self) -> str: ...

    def account_login(self) -> int:
        """Login of the account the terminal is logged into (0 = unknown: account binding is skipped)."""
        return 0

    def account_server(self) -> str:
        return ""

    def is_hedging(self) -> bool:
        """True for hedging accounts (required: one position per strategy and symbol, closed by ticket)."""
        return True

    def free_margin(self) -> float:
        """Free margin in account currency (override in real brokers)."""
        return float("inf")

    def margin_required(self, base: str, direction: int, volume: float, price: float) -> float:
        """Margin needed to open `volume` lots (override in real brokers)."""
        return 0.0

    def cash_flows(self) -> list[CashFlow]:
        """Recent deposits / withdrawals / credit / bonus deals (the engine de-duplicates by ticket)."""
        return []

    def account_money(self) -> float | None:
        """Balance + credit (None = unknown: no cash-flow reconciliation)."""
        return None

    def cash_scan(self, fresh: bool = False, after: int = 0, since: datetime | None = None) -> CashScan:
        """The engine's cash-flow check: the deals with ticket > `after` (all types, with their balance effect;
        `since` = server time of that reference deal, the history window starts a day before it; None = no
        reference yet), then the account (equity, balance + credit). This default knows neither the balance nor the
        deals: cash_flows() are applied by ticket at once (no reconciliation, no lag guard)."""
        flows = self.cash_flows()
        return CashScan(flows, self.account_equity())

    def history_check(self) -> HistoryCheck:
        """First run: every cash deal of the whole history and whether the history is complete (None = cannot be
        checked: the engine primes the cash-flow cursor at once)."""
        return HistoryCheck(self.cash_flows(), None)

    def closed_trade(self, ticket: int) -> ClosedTrade | None:
        """P/L of a position that is no longer open (None while the deal history does not show it yet)."""
        return None

    def versions(self) -> dict[str, str]:
        """Versions of the broker package / terminal for the start-up log and the heartbeat."""
        return {}

    @abstractmethod
    def symbol_spec(self, base: str) -> SymbolSpec: ...

    @abstractmethod
    def tick(self, base: str) -> Tick | None: ...

    @abstractmethod
    def server_time(self) -> datetime | None:
        """Latest known server time (from the most recent tick of any symbol)."""

    @abstractmethod
    def rates(self, base: str, timeframe: str, count: int) -> pd.DataFrame:
        """Closed bars only, index = bar open time (server time), columns open/high/low/close/spread."""

    @abstractmethod
    def positions(self, magics: dict[int, str]) -> list[PositionView]:
        """Open positions belonging to this system. magics maps magic number -> strategy name.
        Must RAISE when the position list cannot be read (an error is never 'no positions')."""

    @abstractmethod
    def loss_per_lot(self, base: str, direction: int, entry: float, stop: float) -> float:
        """Loss (positive, account currency) of 1.0 lot moving from entry to stop."""

    @abstractmethod
    def open_position(self, base: str, direction: int, volume: float, sl: float, tp: float | None,
                      magic: int, comment: str) -> OrderResult: ...

    @abstractmethod
    def modify_position(self, ticket: int, base: str, sl: float | None, tp: float | None) -> OrderResult: ...

    @abstractmethod
    def close_position(self, ticket: int, base: str, comment: str = "") -> OrderResult: ...
